mod sdk;
// 기존 감시기·엔진 파이프라인의 상태를 메모리에 구성해 대시보드에 표시.

use crate::scan_log::{FileScanRecord, FileScanStore, RegexScanRecord, ScanStoreFingerprint};
use askfile::{FileEvent, FileInfo, FolderInfo};
use serde::Serialize;
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

#[derive(Clone)]
pub struct DashboardState {
    inner: Arc<Mutex<State>>,
    persisted_refresh: Arc<Mutex<()>>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ScanTicket {
    row_id: String,
    content_revision: u64,
    event: FileEvent,
}

impl ScanTicket {
    pub fn row_id(&self) -> &str {
        &self.row_id
    }
}

#[derive(Clone, PartialEq, Serialize)]
pub(crate) struct Entry {
    #[serde(skip)]
    pub(crate) row_id: String,
    pub(crate) sequence: u64,
    pub(crate) timestamp_ms: u64,
    pub(crate) file: FileInfo,
    pub(crate) inspection: Value,
    pub(crate) inspection_timestamp_ms: Option<u64>,
    pub(crate) inspection_pending: bool,
    #[serde(skip)]
    pub(crate) content_revision: u64,
}

pub(crate) struct FolderEntry {
    pub(crate) info: FolderInfo,
    members: usize,
    pub(crate) sequence: u64,
    pub(crate) timestamp_ms: u64,
}

#[derive(Default, Serialize)]
struct Counters {
    received: u64,
    initial: u64,
    changes: u64,
    inspection_ok: u64,
    inspection_error: u64,
    inspection_skipped: u64,
    current_files: usize,
    current_directories: usize,
    current_folders: usize,
}

struct CandidateProgress {
    ticket: ScanTicket,
    completed: usize,
    total: usize,
    stage: String,
    started: Instant,
}

struct State {
    sdk_json_path: Option<PathBuf>,
    sdk_json_bytes: Option<Vec<u8>>,
    result_received_at_ms: Option<u64>,
    local_actions: BTreeMap<String, Value>,
    actions_path: Option<PathBuf>,
    revision: u64,
    updated_at_ms: Option<u64>,
    status: String,
    message: Option<String>,
    engine_connected: bool,
    engine_error: Option<String>,
    log_error: Option<String>,
    log_notice: Option<String>,
    initial_progress: Value,
    candidate_progress: Option<CandidateProgress>,
    scan_store: Option<FileScanStore>,
    persisted_fingerprint: Option<ScanStoreFingerprint>,
    roots: Vec<PathBuf>,
    counters: Counters,
    files: BTreeMap<String, Entry>,
    row_paths: BTreeMap<String, String>,
    folders: BTreeMap<String, FolderEntry>,
    events: VecDeque<Entry>,
    scan_history: VecDeque<Entry>,
    scan_history_total: u64,
    scan_generation: u64,
    transient_scan_total: u64,
    // Preserve counts for memory-only runs even when bounded history evicts their rows.
    unsaved_scan_keys: BTreeSet<(String, String)>,
    history_row_counts: BTreeMap<String, usize>,
    history_capacity: usize,
}

pub(crate) struct StateView<'a> {
    pub(crate) result_received_at_ms: Option<u64>,
    pub(crate) local_actions: &'a BTreeMap<String, Value>,
    pub(crate) revision: u64,
    pub(crate) updated_at_ms: Option<u64>,
    pub(crate) status: &'a str,
    pub(crate) message: Option<&'a str>,
    pub(crate) engine_connected: bool,
    pub(crate) engine_error: Option<&'a str>,
    pub(crate) log_error: Option<&'a str>,
    pub(crate) log_notice: Option<&'a str>,
    pub(crate) initial_progress: &'a Value,
    pub(crate) candidate_progress: Value,
    pub(crate) roots: &'a [PathBuf],
    pub(crate) files: &'a BTreeMap<String, Entry>,
    pub(crate) row_paths: &'a BTreeMap<String, String>,
    pub(crate) folders: &'a BTreeMap<String, FolderEntry>,
    pub(crate) events: &'a VecDeque<Entry>,
    pub(crate) scan_history: &'a VecDeque<Entry>,
    pub(crate) scan_history_total: u64,
    pub(crate) counters: Value,
    pub(crate) history: Value,
}

impl DashboardState {
    pub fn new(history_capacity: usize) -> Self {
        Self {
            persisted_refresh: Arc::new(Mutex::new(())),
            inner: Arc::new(Mutex::new(State {
                sdk_json_path: None,
                sdk_json_bytes: None,
                result_received_at_ms: None,
                local_actions: BTreeMap::new(),
                actions_path: None,
                revision: 0,
                updated_at_ms: None,
                status: "idle".into(),
                message: None,
                engine_connected: false,
                engine_error: None,
                log_error: None,
                log_notice: None,
                initial_progress: json!({"phase": "discovering", "total": 0, "completed": 0, "failed": 0}),
                candidate_progress: None,
                scan_store: None,
                persisted_fingerprint: None,
                roots: Vec::new(),
                counters: Counters::default(),
                files: BTreeMap::new(),
                row_paths: BTreeMap::new(),
                folders: BTreeMap::new(),
                events: VecDeque::new(),
                scan_history: VecDeque::new(),
                scan_history_total: 0,
                scan_generation: 0,
                transient_scan_total: 0,
                unsaved_scan_keys: BTreeSet::new(),
                history_row_counts: BTreeMap::new(),
                history_capacity,
            })),
        }
    }

    pub fn load_local_actions(&self, path: PathBuf) -> Result<(), String> {
        let actions = match std::fs::read(&path) {
            Ok(bytes) => serde_json::from_slice::<BTreeMap<String, Value>>(&bytes)
                .map_err(|e| e.to_string())?,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => BTreeMap::new(),
            Err(e) => return Err(e.to_string()),
        };
        let mut state = self.lock();
        state.local_actions = actions;
        state.actions_path = Some(path);
        state.revision = state.revision.wrapping_add(1);
        Ok(())
    }

    pub fn set_local_action(&self, key: &str, to: &str, expected: u64) -> Result<(), String> {
        let mut state = self.lock();
        let old = state
            .local_actions
            .get(key)
            .cloned()
            .unwrap_or_else(|| json!({"status":"open","version":0,"history":[]}));
        if old["version"].as_u64().unwrap_or(0) != expected {
            return Err("조치 상태가 변경되었습니다. 새로고침 후 다시 시도하세요.".into());
        }
        let from = old["status"].as_str().unwrap_or("open");
        let allowed = match from {
            "open" => matches!(to, "in_progress" | "resolved" | "false_positive"),
            "in_progress" => matches!(to, "open" | "resolved" | "false_positive"),
            "resolved" | "false_positive" => to == "open",
            _ => false,
        };
        if key.is_empty() || !allowed {
            return Err("허용되지 않은 조치 상태 변경입니다.".into());
        }
        let mut history = old["history"].as_array().cloned().unwrap_or_default();
        let at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;
        history.push(json!({"from":from,"to":to,"at":at}));
        let mut next = state.local_actions.clone();
        next.insert(
            key.into(),
            json!({"status":to,"version":expected+1,"history":history}),
        );
        if let Some(path) = &state.actions_path {
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            let temp = path.with_extension("tmp");
            std::fs::write(
                &temp,
                serde_json::to_vec_pretty(&next).map_err(|e| e.to_string())?,
            )
            .map_err(|e| e.to_string())?;
            std::fs::rename(&temp, path).map_err(|e| e.to_string())?;
        }
        state.local_actions = next;
        state.revision = state.revision.wrapping_add(1);
        Ok(())
    }

    pub fn set_status(&self, status: &str, message: Option<String>) {
        let mut state = self.lock();
        if state.status != status || state.message != message {
            state.status = status.to_owned();
            state.message = message;
            state.revision = state.revision.wrapping_add(1);
        }
    }

    pub fn set_roots(&self, roots: Vec<PathBuf>) {
        let mut state = self.lock();
        if state.roots != roots {
            state.roots = roots;
            state.revision = state.revision.wrapping_add(1);
        }
    }

    pub fn roots(&self) -> Vec<PathBuf> {
        self.lock().roots.clone()
    }

    pub fn set_engine_status(&self, connected: bool, error: Option<String>) {
        let mut state = self.lock();
        if state.engine_connected != connected || state.engine_error != error {
            state.engine_connected = connected;
            state.engine_error = error;
            state.revision = state.revision.wrapping_add(1);
        }
    }

    pub fn set_initial_progress(&self, phase: &str, total: u64, completed: u64, failed: u64) {
        let progress = json!({
            "phase": phase, "total": total,
            "completed": completed.min(total), "failed": failed.min(completed).min(total),
        });
        let mut state = self.lock();
        if state.initial_progress != progress {
            state.initial_progress = progress;
            state.revision = state.revision.wrapping_add(1);
        }
    }

    pub fn set_candidate_progress(
        &self,
        ticket: &ScanTicket,
        completed: usize,
        total: usize,
        stage: &str,
    ) -> bool {
        let mut state = self.lock();
        let valid = state
            .row_paths
            .get(&ticket.row_id)
            .and_then(|path| state.files.get(path))
            .is_some_and(|entry| {
                entry.content_revision == ticket.content_revision
                    && entry.inspection_pending
                    && askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_none()
            });
        if !valid {
            state.clear_stale_candidate_progress();
            return false;
        }
        let completed = completed.min(total);
        if let Some(progress) = state
            .candidate_progress
            .as_mut()
            .filter(|progress| progress.ticket == *ticket)
        {
            if progress.completed == completed && progress.total == total && progress.stage == stage
            {
                return true;
            }
            progress.completed = completed;
            progress.total = total;
            progress.stage = stage.to_owned();
        } else {
            state.candidate_progress = Some(CandidateProgress {
                ticket: ticket.clone(),
                completed,
                total,
                stage: stage.to_owned(),
                started: Instant::now(),
            });
        }
        state.updated_at_ms = Some(now_ms());
        state.revision = state.revision.wrapping_add(1);
        true
    }

    pub fn set_scan_store(&self, store: FileScanStore) {
        let _refresh = self
            .persisted_refresh
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let mut state = self.lock();
        state.scan_store = Some(store);
        state.persisted_fingerprint = None;
    }

    pub fn refresh_persisted(&self) -> Result<(), String> {
        let _refresh = self
            .persisted_refresh
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let sdk_path = self.lock().sdk_json_path.clone();
        if let Some(path) = sdk_path {
            let result = self.refresh_sdk_json(&path);
            self.set_log_error(result.as_ref().err().cloned());
            return result;
        }
        let (store, previous, capacity, previous_error, observed_scans) = {
            let state = self.lock();
            (
                state.scan_store.clone(),
                state.persisted_fingerprint.clone(),
                state.history_capacity,
                state.log_error.clone(),
                state.scan_generation,
            )
        };
        let Some(store) = store else {
            return Ok(());
        };
        let mut fingerprint = match store.fingerprint() {
            Ok(fingerprint) => fingerprint,
            Err(error) => {
                let message = format!("저장된 검사 내역을 조회하지 못했습니다: {error}");
                self.set_log_error(Some(message.clone()));
                return Err(message);
            }
        };
        if previous.as_ref() == Some(&fingerprint) && previous_error.is_none() {
            return Ok(());
        }
        let mut saved = store.read_dashboard(&fingerprint, capacity);
        let mut recovery_notice = None;
        if !saved.errors.is_empty() {
            let recovery = store.recover_corrupt_latest(&fingerprint);
            if !recovery.warnings.is_empty() {
                recovery_notice = Some(recovery.warnings.join("\n"));
            }
            if recovery.repaired > 0 {
                match store.fingerprint() {
                    Ok(repaired_fingerprint) => {
                        fingerprint = repaired_fingerprint;
                        saved = store.read_dashboard(&fingerprint, capacity);
                    }
                    Err(error) => saved
                        .errors
                        .push(format!("복원된 검사 기록 확인 실패: {error}")),
                }
            }
            saved.errors.extend(recovery.errors);
        }
        let message = saved
            .errors
            .first()
            .map(|first| format!("{first} (총 {}건)", saved.errors.len()));
        let candidates: Vec<_> = {
            let state = self.lock();
            state
                .files
                .values()
                .filter(|entry| {
                    !entry.inspection_pending
                        && entry.file.is_directory == Some(false)
                        && askfile::scan_exclusion_reason(&state.current_entry(entry).file)
                            .is_none()
                })
                .filter_map(|entry| {
                    let id = crate::persisted::file_log_id(&entry.file)?;
                    let record = saved.latest.get(&id)?;
                    if record.scan_status == "excluded" && is_env_path(&entry.file.path) {
                        return None;
                    }
                    if saved_is_older(record, &entry.inspection) {
                        return None;
                    }
                    let inspection = crate::persisted::inspection(record);
                    (entry.inspection != inspection).then(|| {
                        (
                            entry.row_id.clone(),
                            entry.content_revision,
                            entry.file.path.clone(),
                            id,
                            entry.inspection.clone(),
                            inspection,
                        )
                    })
                })
                .collect()
        };
        let updates: Vec<_> = candidates
            .into_iter()
            .filter_map(
                |(row_id, revision, path, id, previous_inspection, inspection)| {
                    let record = saved.latest.get(&id)?;
                    let stamp = record
                        .metadata
                        .get("content_stamp")
                        .filter(|stamp| !stamp.is_null())?;
                    (crate::persisted::content_stamp(&path).as_ref() == Some(stamp)).then(|| {
                        (
                            row_id,
                            revision,
                            path,
                            previous_inspection,
                            inspection,
                            record.processed_at.timestamp_millis().max(0) as u64,
                        )
                    })
                },
            )
            .collect();
        let mut state = self.lock();
        let concurrent_scans = state.scan_generation != observed_scans;
        let mut changed = false;
        for (row_id, revision, path, previous_inspection, inspection, processed) in updates {
            if state.files.get(&path_key(&path)).is_some_and(|entry| {
                askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_some()
            }) {
                continue;
            }
            let Some(entry) = state.files.get_mut(&path_key(&path)) else {
                continue;
            };
            if entry.row_id != row_id
                || entry.content_revision != revision
                || entry.inspection_pending
                || entry.inspection != previous_inspection
            {
                continue;
            }
            entry.inspection = inspection.clone();
            entry.inspection_timestamp_ms = Some(processed);
            state.count_inspection(&inspection);
            changed = true;
        }
        let mut persisted_keys = BTreeSet::new();
        for record in saved.latest.values().chain(saved.history.iter()) {
            let key = (record.file_id.clone(), record.run_id.clone());
            if record.scan_status != "awaiting_jev" {
                state.unsaved_scan_keys.remove(&key);
            }
            persisted_keys.insert(key);
        }
        let mut unique: BTreeMap<_, _> = state
            .scan_history
            .iter()
            .filter(|entry| {
                concurrent_scans
                    || message.is_some()
                    || persisted_scan_key(entry).is_none()
                    || persisted_scan_key(entry)
                        .is_some_and(|key| state.unsaved_scan_keys.contains(&key))
                    || entry.inspection.get("Err").is_some()
            })
            .map(|entry| (scan_key(entry), entry.clone()))
            .collect();
        for record in &saved.history {
            let entry = persisted_entry(record);
            let key = scan_key(&entry);
            if unique
                .get(&key)
                .is_some_and(|current| saved_is_older(record, &current.inspection))
            {
                continue;
            }
            unique.insert(key, entry);
        }
        let mut history: Vec<_> = unique.into_values().collect();
        history.sort_by_key(|entry| (entry.inspection_timestamp_ms.unwrap_or(0), scan_key(entry)));
        if history.len() > capacity {
            history.drain(..history.len() - capacity);
        }
        let next: VecDeque<_> = history.into();
        if state.scan_history != next {
            state.scan_history = next;
            changed = true;
        }
        let mut total = saved
            .total
            .saturating_add(state.transient_scan_total)
            .saturating_add(state.unsaved_scan_keys.difference(&persisted_keys).count() as u64);
        if concurrent_scans || message.is_some() {
            total = total.max(state.scan_history_total);
        }
        if state.scan_history_total != total {
            state.scan_history_total = total;
            changed = true;
        }
        if state.log_error != message {
            state.log_error = message.clone();
            changed = true;
        }
        if let Some(notice) = recovery_notice {
            if state.log_notice.as_ref() != Some(&notice) {
                state.log_notice = Some(notice);
                changed = true;
            }
        }

        state.persisted_fingerprint = (!concurrent_scans).then_some(fingerprint);
        if changed {
            state.updated_at_ms = Some(now_ms());
            state.result_received_at_ms = state.updated_at_ms;
            state.revision = state.revision.wrapping_add(1);
        }
        message.map_or(Ok(()), Err)
    }

    fn set_log_error(&self, error: Option<String>) {
        let mut state = self.lock();
        if state.log_error != error {
            state.log_error = error;
            state.revision = state.revision.wrapping_add(1);
        }
    }

    pub fn revision(&self) -> u64 {
        self.lock().revision
    }

    pub fn observe(&self, file: FileInfo) -> Result<Option<ScanTicket>, String> {
        Ok(self.record_file(file, None))
    }

    pub fn observe_initial(
        &self,
        file: FileInfo,
        store: &FileScanStore,
    ) -> Result<Option<ScanTicket>, String> {
        let ticket = self.observe(file.clone())?;
        if ticket.is_some()
            || file.event.is_some()
            || file.is_directory != Some(false)
            || askfile::scan_exclusion_reason(&file).is_some()
        {
            return Ok(ticket);
        }
        match self.restore_persisted(&file, store) {
            Ok(_) => {}
            Err(error) => self.set_log_error(Some(format!(
                "저장 결과를 재사용하지 못해 다시 검사합니다: {error}"
            ))),
        }
        let mut state = self.lock();
        let Some(entry) = state.files.get_mut(&path_key(&file.path)) else {
            return Ok(None);
        };
        let reusable = !entry.inspection.is_null()
            && !inspection_failed(&entry.inspection)
            && !inspection_incomplete(&entry.inspection)
            && !(entry.inspection["Ok"]["status"] == "excluded" && is_env_path(&entry.file.path));
        if entry.file.identity != file.identity || entry.inspection_pending || reusable {
            return Ok(None);
        }
        entry.inspection_pending = true;
        let ticket = ScanTicket {
            row_id: entry.row_id.clone(),
            content_revision: entry.content_revision,
            event: FileEvent::Modified,
        };
        state.revision = state.revision.wrapping_add(1);
        Ok(Some(ticket))
    }

    pub fn resolve(&self, ticket: &ScanTicket) -> Option<FileInfo> {
        let state = self.lock();
        let path = state.row_paths.get(&ticket.row_id)?;
        let entry = state.files.get(path)?;
        let current = state.current_entry(entry).file;
        (entry.content_revision == ticket.content_revision
            && entry.inspection_pending
            && askfile::scan_exclusion_reason(&current).is_none())
        .then(|| {
            let mut file = current;

            file.event = Some(ticket.event.clone());
            file
        })
    }

    pub fn initial_outcome(&self, ticket: &ScanTicket) -> Option<bool> {
        let state = self.lock();
        let Some(entry) = state
            .row_paths
            .get(&ticket.row_id)
            .and_then(|path| state.files.get(path))
        else {
            return Some(false);
        };

        if askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_some() {
            return Some(false);
        }
        if entry.inspection_pending {
            return None;
        }
        Some(inspection_failed(&entry.inspection))
    }

    pub fn complete<R: Serialize>(
        &self,
        ticket: &ScanTicket,
        result: Result<R, String>,
    ) -> Result<bool, String> {
        let mut inspection = serde_json::to_value(&result)
            .map_err(|error| format!("Cannot serialize inspection result: {error}"))?;
        let mut state = self.lock();
        let Some(path) = state.row_paths.get(&ticket.row_id).cloned() else {
            return Ok(false);
        };
        let Some(entry) = state.files.get(&path) else {
            return Ok(false);
        };
        if entry.content_revision != ticket.content_revision
            || !entry.inspection_pending
            || askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_some()
        {
            return Ok(false);
        }
        if let Err(error) = &result {
            if inspection_incomplete(&entry.inspection) {
                let mut report = entry.inspection["Ok"].clone();
                report["status"] = json!("failed");
                report["jev_status"] = json!("failed");
                report["reason"] = json!(error);
                report["error_code"] = json!(error);
                if let Some(findings) = report["findings"].as_array_mut() {
                    for finding in findings {
                        finding["status"] = json!("needs_review");
                        finding["jev_status"] = json!("failed");
                        finding["review_required"] = json!(true);
                        finding["error_code"] = json!(error);
                    }
                }
                inspection["Ok"] = report;
            }
        }
        state.finish_inspection(&path, inspection, now_ms());
        Ok(true)
    }

    /// 정규식 후보는 메모리에만 표시하고 최종 JEV 결과를 기다립니다.
    pub fn publish_regex(
        &self,
        ticket: &ScanTicket,
        record: &RegexScanRecord,
    ) -> Result<bool, String> {
        let mut state = self.lock();
        let Some(path) = state.row_paths.get(&ticket.row_id).cloned() else {
            return Ok(false);
        };
        let Some(entry) = state.files.get(&path) else {
            return Ok(false);
        };
        if entry.content_revision != ticket.content_revision
            || !entry.inspection_pending
            || askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_some()
        {
            return Ok(false);
        }
        let file = state.current_entry(entry).file;
        let file_id = crate::persisted::file_log_id(&file).ok_or("FILE_ID_REQUIRED")?;
        let record_id = crate::scan_log::normalize_file_id(&record.file_id)
            .map_err(|error| error.to_string())?;
        if record_id != file_id {
            return Err("FILE_ID_MISMATCH".into());
        }
        if let Some(expected) = record
            .metadata
            .get("content_stamp")
            .filter(|stamp| !stamp.is_null())
        {
            if crate::persisted::content_stamp(&file.path).as_ref() != Some(expected) {
                state.finish_inspection(
                    &path,
                    json!({"Err": "CONTENT_CHANGED_SINCE_SCAN"}),
                    now_ms(),
                );
                return Ok(false);
            }
        }
        let mut current = record.clone();
        current.file_id = file_id;
        current.file_path = file.path.to_string_lossy().into_owned();
        current.metadata.insert(
            "file_info".into(),
            serde_json::to_value(&file).map_err(|error| error.to_string())?,
        );
        state
            .unsaved_scan_keys
            .insert((current.file_id.clone(), current.run_id.clone()));
        let staged = current.dashboard_record();
        let inspected_at = staged.processed_at.timestamp_millis().max(0) as u64;
        state.set_inspection(
            &path,
            crate::persisted::inspection(&staged),
            inspected_at,
            true,
        );
        Ok(true)
    }

    /// 현재 내용의 검사만 저장 후 저장된 결과를 표시.
    pub fn complete_persisted(
        &self,
        ticket: &ScanTicket,
        store: &FileScanStore,
        record: &FileScanRecord,
    ) -> Result<bool, String> {
        let mut state = self.lock();
        let Some(path) = state.row_paths.get(&ticket.row_id).cloned() else {
            return Ok(false);
        };
        let Some(entry) = state.files.get(&path) else {
            return Ok(false);
        };
        if entry.content_revision != ticket.content_revision
            || !entry.inspection_pending
            || askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_some()
        {
            return Ok(false);
        }
        let file = state.current_entry(entry).file;
        let file_id = crate::persisted::file_log_id(&file).ok_or("FILE_ID_REQUIRED")?;
        let record_id = crate::scan_log::normalize_file_id(&record.file_id)
            .map_err(|error| error.to_string())?;
        if record_id != file_id {
            return Err("FILE_ID_MISMATCH".into());
        }
        if let Some(expected) = record
            .metadata
            .get("content_stamp")
            .filter(|stamp| !stamp.is_null())
        {
            if crate::persisted::content_stamp(&file.path).as_ref() != Some(expected) {
                state.finish_inspection(
                    &path,
                    json!({"Err": "CONTENT_CHANGED_SINCE_SCAN"}),
                    now_ms(),
                );
                return Ok(false);
            }
        }
        let mut current = record.clone();
        current.file_path = file.path.to_string_lossy().into_owned();
        current.metadata.insert(
            "file_info".into(),
            serde_json::to_value(&file).map_err(|error| error.to_string())?,
        );
        store.publish(&current).map_err(|error| error.to_string())?;
        state
            .unsaved_scan_keys
            .remove(&(file_id.clone(), current.run_id.clone()));
        let saved = store
            .read_latest(&file_id)
            .map_err(|error| error.to_string())?
            .ok_or("PERSISTED_SCAN_MISSING")?;
        if saved.file_id != file_id {
            return Err("PERSISTED_FILE_ID_MISMATCH".into());
        }

        if let Some(expected) = current
            .metadata
            .get("content_stamp")
            .filter(|stamp| !stamp.is_null())
        {
            if saved.metadata.get("content_stamp") != Some(expected) {
                return Err("PERSISTED_CONTENT_STAMP_MISMATCH".into());
            }
        }
        if let Some(saved_stamp) = saved
            .metadata
            .get("content_stamp")
            .filter(|stamp| !stamp.is_null())
        {
            if crate::persisted::content_stamp(&file.path).as_ref() != Some(saved_stamp) {
                return Err("PERSISTED_CONTENT_STAMP_MISMATCH".into());
            }
        }
        let inspected_at = saved.processed_at.timestamp_millis().max(0) as u64;
        state.finish_inspection(&path, crate::persisted::inspection(&saved), inspected_at);
        Ok(true)
    }

    pub fn restore_persisted(
        &self,
        file: &FileInfo,
        store: &FileScanStore,
    ) -> Result<bool, String> {
        if file.is_directory != Some(false) || askfile::scan_exclusion_reason(file).is_some() {
            return Ok(false);
        }
        let Some(file_id) = crate::persisted::file_log_id(file) else {
            return Ok(false);
        };
        let mut state = self.lock();
        let path = path_key(&file.path);
        let Some(entry) = state.files.get(&path) else {
            return Ok(false);
        };
        if entry.file.identity != file.identity
            || entry.inspection_pending
            || !entry.inspection.is_null()
            || askfile::scan_exclusion_reason(&state.current_entry(entry).file).is_some()
        {
            return Ok(false);
        }
        let Some(saved) = store
            .read_latest(&file_id)
            .map_err(|error| error.to_string())?
        else {
            return Ok(false);
        };
        if saved.file_id != file_id {
            return Err("PERSISTED_FILE_ID_MISMATCH".into());
        }
        if saved.scan_status == "excluded" && is_env_path(&entry.file.path) {
            return Ok(false);
        }
        let Some(expected) = saved
            .metadata
            .get("content_stamp")
            .filter(|stamp| !stamp.is_null())
        else {
            return Ok(false);
        };
        if crate::persisted::content_stamp(&entry.file.path).as_ref() != Some(expected) {
            return Ok(false);
        }
        let inspected_at = saved.processed_at.timestamp_millis().max(0) as u64;
        state.finish_inspection(&path, crate::persisted::inspection(&saved), inspected_at);
        Ok(true)
    }

    fn record_file(&self, file: FileInfo, inspection: Option<Value>) -> Option<ScanTicket> {
        let mut state = self.lock();
        state.counters.received += 1;
        if file.event.is_none() {
            state.counters.initial += 1;
        } else {
            state.counters.changes += 1;
        }
        let source = match &file.event {
            Some(FileEvent::Renamed { old_path, .. }) => old_path,
            _ => &file.path,
        };
        let previous = state
            .files
            .get(&path_key(source))
            .filter(|entry| entry.file.identity == file.identity || file.identity.is_none());
        let deleted = matches!(file.event, Some(FileEvent::Deleted));
        let exclusion = (!deleted)
            .then(|| askfile::scan_exclusion_reason(&file))
            .flatten();
        let policy_became_eligible = exclusion.is_none()
            && previous.is_some_and(|entry| entry.inspection["Ok"]["policy_excluded"] == true);
        let changed = file.is_directory == Some(false)
            && !deleted
            && exclusion.is_none()
            && (matches!(file.event, Some(FileEvent::Created | FileEvent::Modified))
                || policy_became_eligible);
        let scan_event = changed.then(|| match file.event {
            Some(FileEvent::Created) => FileEvent::Created,
            _ => FileEvent::Modified,
        });
        let timestamp_ms = now_ms();
        let mut entry = Entry {
            row_id: state.row_id(&file),
            sequence: state.counters.received,
            timestamp_ms,
            inspection: Value::Null,
            inspection_timestamp_ms: None,
            inspection_pending: changed && inspection.is_none(),
            content_revision: state.counters.received,
            file,
        };
        if !changed {
            if let Some(previous) = previous {
                entry.inspection = previous.inspection.clone();
                entry.inspection_timestamp_ms = previous.inspection_timestamp_ms;
                entry.inspection_pending = previous.inspection_pending;
                entry.content_revision = previous.content_revision;
            }
        }
        if deleted {
            entry.inspection_pending = false;
        }
        if let Some(reason) = exclusion {
            exclude_entry(&mut entry, reason, state.counters.received);
            state.counters.inspection_skipped += 1;
        } else if let Some(inspection) = inspection {
            entry.inspection = inspection;
            entry.inspection_timestamp_ms = Some(timestamp_ms);
            state.result_received_at_ms = Some(timestamp_ms);
            entry.inspection_pending = false;
            state.count_inspection(&entry.inspection);
            state.push_scan(entry.clone(), false);
        } else if !changed {
            state.counters.inspection_skipped += 1;
        }
        let ticket = (changed && entry.inspection_pending).then(|| ScanTicket {
            row_id: entry.row_id.clone(),
            content_revision: entry.content_revision,
            event: scan_event.expect("changed file has an event"),
        });
        state.updated_at_ms = Some(entry.timestamp_ms);
        state.apply(&entry);
        state.clear_stale_candidate_progress();
        if state.history_capacity > 0 {
            if state.events.len() == state.history_capacity {
                if let Some(expired) = state.events.pop_front() {
                    if let Some(count) = state.history_row_counts.get_mut(&expired.row_id) {
                        *count -= 1;
                        if *count == 0 {
                            state.history_row_counts.remove(&expired.row_id);
                        }
                    }
                }
            }
            *state
                .history_row_counts
                .entry(entry.row_id.clone())
                .or_default() += 1;
            state.events.push_back(entry);
        }
        state.revision = state.revision.wrapping_add(1);
        ticket
    }

    fn lock(&self) -> MutexGuard<'_, State> {
        self.inner.lock().unwrap_or_else(|error| error.into_inner())
    }

    pub(crate) fn read<T>(&self, read: impl FnOnce(StateView<'_>) -> T) -> T {
        let state = self.lock();
        read(StateView {
            result_received_at_ms: state.result_received_at_ms,
            local_actions: &state.local_actions,
            revision: state.revision,
            updated_at_ms: state.updated_at_ms,
            status: &state.status,
            message: state.message.as_deref(),
            engine_connected: state.engine_connected,
            engine_error: state.engine_error.as_deref(),
            log_error: state.log_error.as_deref(),
            log_notice: state.log_notice.as_deref(),
            initial_progress: &state.initial_progress,
            candidate_progress: state.candidate_progress_value(),
            roots: &state.roots,
            files: &state.files,
            row_paths: &state.row_paths,
            folders: &state.folders,
            events: &state.events,
            scan_history: &state.scan_history,
            scan_history_total: state.scan_history_total,
            counters: json!(state.counters),
            history: state.history(),
        })
    }
}

impl State {
    fn candidate_progress_value(&self) -> Value {
        let Some(progress) = &self.candidate_progress else {
            return Value::Null;
        };
        let Some(entry) = self
            .row_paths
            .get(&progress.ticket.row_id)
            .and_then(|path| self.files.get(path))
            .filter(|entry| {
                entry.content_revision == progress.ticket.content_revision
                    && entry.inspection_pending
                    && askfile::scan_exclusion_reason(&self.current_entry(entry).file).is_none()
            })
        else {
            return Value::Null;
        };
        json!({
            "file_path": entry.file.path,
            "completed": progress.completed,
            "total": progress.total,
            "stage": progress.stage,
            "elapsed_ms": progress.started.elapsed().as_millis().min(u64::MAX as u128) as u64,
            "sampled_at_ms": now_ms(),
        })
    }

    fn clear_stale_candidate_progress(&mut self) {
        let stale = self.candidate_progress.as_ref().is_some_and(|progress| {
            !self
                .row_paths
                .get(&progress.ticket.row_id)
                .and_then(|path| self.files.get(path))
                .is_some_and(|entry| {
                    entry.content_revision == progress.ticket.content_revision
                        && entry.inspection_pending
                        && askfile::scan_exclusion_reason(&self.current_entry(entry).file).is_none()
                })
        });
        if stale {
            self.candidate_progress = None;
        }
    }

    fn finish_inspection(&mut self, path: &str, inspection: Value, inspected_at: u64) {
        self.set_inspection(path, inspection, inspected_at, false);
    }

    fn set_inspection(&mut self, path: &str, inspection: Value, inspected_at: u64, pending: bool) {
        let entry = self.files.get_mut(path).expect("validated inspection row");
        let previous_key = persisted_scan_key(entry);
        entry.inspection = inspection;
        entry.inspection_pending = pending;
        entry.inspection_timestamp_ms = Some(inspected_at);
        let replacing = previous_key.is_some() && previous_key == persisted_scan_key(entry);
        let mut completed = entry.clone();
        completed.timestamp_ms = inspected_at;
        if !pending {
            self.count_inspection(&completed.inspection);
        }
        self.push_scan(completed, replacing);
        self.clear_stale_candidate_progress();
        self.updated_at_ms = Some(now_ms());
        self.result_received_at_ms = self.updated_at_ms;
        self.revision = self.revision.wrapping_add(1);
    }

    fn count_inspection(&mut self, inspection: &Value) {
        if inspection_incomplete(inspection) {
            return;
        }
        let status = inspection
            .get("Ok")
            .and_then(|report| report.get("status"))
            .and_then(Value::as_str);
        if inspection_failed(inspection) {
            self.counters.inspection_error += 1;
        } else if matches!(status, Some("skipped" | "excluded")) {
            self.counters.inspection_skipped += 1;
        } else {
            self.counters.inspection_ok += 1;
        }
    }

    fn push_scan(&mut self, entry: Entry, replacing: bool) {
        self.scan_generation = self.scan_generation.wrapping_add(1);
        let key = scan_key(&entry);
        if let Some(index) = self
            .scan_history
            .iter()
            .position(|previous| scan_key(previous) == key)
        {
            self.scan_history.remove(index);
        } else if !replacing {
            self.scan_history_total += 1;
            if persisted_scan_key(&entry).is_none() {
                self.transient_scan_total += 1;
            }
        }
        if self.history_capacity == 0 {
            return;
        }
        self.scan_history.push_back(entry);
        self.scan_history
            .make_contiguous()
            .sort_by_key(|entry| (entry.inspection_timestamp_ms.unwrap_or(0), scan_key(entry)));
        if self.scan_history.len() > self.history_capacity {
            self.scan_history.pop_front();
        }
    }

    fn row_id(&self, file: &FileInfo) -> String {
        let source = match &file.event {
            Some(FileEvent::Renamed { old_path, .. }) => old_path,
            _ => &file.path,
        };
        if let Some(previous) = self.files.get(&path_key(source)) {
            if previous.file.identity == file.identity || file.identity.is_none() {
                return previous.row_id.clone();
            }
        }
        if matches!(file.event, Some(FileEvent::Deleted)) {
            let key = path_key(&file.path);
            if let Some(previous) = self.events.iter().rev().find(|entry| {
                matches!(entry.file.event, Some(FileEvent::Deleted))
                    && path_key(&entry.file.path) == key
                    && (entry.file.identity == file.identity || file.identity.is_none())
            }) {
                return previous.row_id.clone();
            }
        }
        match file.identity {
            Some(identity) => {
                let base = format!(
                    "ntfs-{:08x}-{:016x}",
                    identity.volume_serial_number, identity.file_reference_number
                );

                let key = path_key(&file.path);
                let occupied = if let Some(path) = self.row_paths.get(&base) {
                    path != &key
                } else if self.history_row_counts.contains_key(&base) {
                    self.events
                        .iter()
                        .rev()
                        .find(|entry| entry.row_id == base)
                        .is_some_and(|entry| path_key(&entry.file.path) != key)
                } else {
                    false
                };
                if occupied {
                    format!("{base}-link-{:016x}", self.counters.received)
                } else {
                    base
                }
            }
            None => format!("legacy-{:016x}", self.counters.received),
        }
    }

    fn history(&self) -> Value {
        json!({
            "capacity": self.history_capacity,
            "retained": self.events.len(),
            "dropped": self.counters.received.saturating_sub(self.events.len() as u64),
            "oldest_sequence": self.events.front().map(|entry| entry.sequence),
            "latest_sequence": if self.counters.received == 0 { None } else { Some(self.counters.received) },
        })
    }

    fn current_entry(&self, entry: &Entry) -> Entry {
        let mut current = entry.clone();
        if let Some(folder) = &entry.file.folder {
            if let Some(latest) = self.folders.get(&path_key(&folder.folder_path)) {
                current.file.folder = Some(latest.info.clone());
            }
        }
        current
    }

    fn remove(&mut self, key: &str) -> Option<Entry> {
        let entry = self.files.remove(key)?;
        self.row_paths.remove(&entry.row_id);
        if entry.file.is_directory == Some(true) {
            self.counters.current_directories -= 1;
        } else {
            self.counters.current_files -= 1;
        }
        if let Some(folder) = &entry.file.folder {
            let folder_key = path_key(&folder.folder_path);
            if let Some(group) = self.folders.get_mut(&folder_key) {
                group.members -= 1;
                if group.members == 0 {
                    self.folders.remove(&folder_key);
                }
            }
        }
        self.counters.current_folders = self.folders.len();
        Some(entry)
    }

    fn insert(&mut self, entry: Entry) {
        let key = path_key(&entry.file.path);
        self.remove(&key);
        let mut changed_policy = None;
        if entry.file.is_directory == Some(true) {
            self.counters.current_directories += 1;
        } else {
            self.counters.current_files += 1;
        }
        if let Some(folder) = &entry.file.folder {
            let group = self
                .folders
                .entry(path_key(&folder.folder_path))
                .or_insert_with(|| FolderEntry {
                    info: folder.clone(),
                    members: 0,
                    sequence: entry.sequence,
                    timestamp_ms: entry.timestamp_ms,
                });
            if entry.sequence >= group.sequence {
                if group.info != *folder {
                    changed_policy = Some(folder.clone());
                }
                group.info = folder.clone();
                group.sequence = entry.sequence;
                group.timestamp_ms = entry.timestamp_ms;
            }
            group.members += 1;
        }
        self.row_paths.insert(entry.row_id.clone(), key.clone());
        self.files.insert(key, entry);
        if let Some(folder) = changed_policy {
            self.apply_folder_exclusions(&folder);
        }
        self.counters.current_folders = self.folders.len();
    }

    fn apply_folder_exclusions(&mut self, folder: &FolderInfo) {
        let folder_key = path_key(&folder.folder_path);
        let prefix = if folder_key.ends_with('/') {
            folder_key.clone()
        } else {
            format!("{folder_key}/")
        };
        for (_, entry) in self
            .files
            .range_mut(prefix.clone()..)
            .take_while(|(path, _)| path.starts_with(&prefix))
        {
            if !entry
                .file
                .folder
                .as_ref()
                .is_some_and(|group| path_key(&group.folder_path) == folder_key)
            {
                continue;
            }
            let mut current = entry.file.clone();
            current.folder = Some(folder.clone());
            if let Some(reason) = askfile::scan_exclusion_reason(&current) {
                if entry.inspection["Ok"]["policy_excluded"] != true
                    || entry.inspection["Ok"]["reason_code"] != reason
                {
                    exclude_entry(entry, reason, self.counters.received);
                }
            }
        }
    }

    fn apply(&mut self, entry: &Entry) {
        match &entry.file.event {
            Some(FileEvent::Deleted) => {
                let key = path_key(&entry.file.path);

                let removed: Vec<_> = self
                    .files
                    .keys()
                    .filter(|candidate| is_within(candidate, &key))
                    .cloned()
                    .collect();
                for key in removed {
                    self.remove(&key);
                }
                for group in self.folders.values_mut() {
                    remove_metadata_paths(&mut group.info, &key);
                }
            }
            Some(FileEvent::Renamed { old_path, .. }) => {
                let old_key = path_key(old_path);
                let moved: Vec<_> = self
                    .files
                    .iter()
                    .filter(|(key, _)| is_within(key, &old_key))
                    .map(|(key, value)| (key.clone(), self.current_entry(value)))
                    .collect();
                for (key, _) in &moved {
                    self.remove(key);
                }
                for group in self.folders.values_mut() {
                    rename_metadata_paths(&mut group.info, old_path, &entry.file.path);
                }
                for (key, mut child) in moved {
                    if key == old_key {
                        continue;
                    }
                    child.file.path = relocate(&child.file.path, old_path, &entry.file.path)
                        .expect("selected descendant must have the old path prefix");
                    if let Some(folder) = &mut child.file.folder {
                        if is_within(&path_key(&folder.folder_path), &old_key) {
                            rename_metadata_paths(folder, old_path, &entry.file.path);
                        } else {
                            child.file.folder = entry.file.folder.clone();
                        }
                    } else {
                        child.file.folder = entry.file.folder.clone();
                    }
                    if let Some(reason) = askfile::scan_exclusion_reason(&child.file) {
                        exclude_entry(&mut child, reason, entry.sequence);
                    }
                    self.insert(child);
                }
                self.insert(entry.clone());
            }
            _ => self.insert(entry.clone()),
        }
    }
}

fn exclude_entry(entry: &mut Entry, reason: &str, revision: u64) {
    let explanation = match reason {
        "GITIGNORED_LOCAL_DATA" => "Git에서 무시하는 추적되지 않은 로컬 데이터 파일입니다.",
        "GIT_POLICY_METADATA" => "Git 무시 규칙을 갱신하는 파일이므로 내용을 검사하지 않습니다.",
        "EXCLUDED_DIRECTORY" => "의존성·빌드·캐시 등 검사 제외 경로입니다.",
        "EXCLUDED_FILE_TYPE" => "의존성 메타데이터 또는 검사 대상이 아닌 파일 형식입니다.",
        _ => "파일 수집 정책에 따라 검사에서 제외했습니다.",
    };
    entry.inspection = json!({"Ok": {
        "status": "excluded", "reason": explanation, "reason_code": reason, "policy_excluded": true,
        "regex_status": "not_run", "jev_status": "not_run", "findings": []
    }});
    entry.inspection_timestamp_ms = None;
    entry.inspection_pending = false;
    entry.content_revision = revision;
}

fn is_env_path(path: &Path) -> bool {
    path.file_name()
        .and_then(|name| name.to_str())
        .map(str::to_ascii_lowercase)
        .is_some_and(|name| name == ".env" || name.starts_with(".env.") || name.ends_with(".env"))
}

fn inspection_incomplete(inspection: &Value) -> bool {
    inspection["Ok"]["status"] == "awaiting_jev" || inspection["Ok"]["jev_status"] == "awaiting_jev"
}

fn inspection_failed(inspection: &Value) -> bool {
    let report = &inspection["Ok"];
    if inspection.get("Err").is_some() || report["status"] == "failed" {
        return true;
    }
    if report["status"] == "excluded" {
        return false;
    }
    report["findings"].as_array().is_some_and(|findings| {
        findings.iter().any(|finding| {
            finding["status"] != "excluded"
                && finding["error_code"]
                    .as_str()
                    .is_some_and(|code| !code.trim().is_empty())
        })
    })
}

fn saved_is_older(record: &FileScanRecord, inspection: &Value) -> bool {
    let report = &inspection["Ok"];

    if record.run_id == report["run_id"].as_str().unwrap_or("")
        && record.scan_status == "awaiting_jev"
        && !inspection_incomplete(inspection)
    {
        return true;
    }
    let Ok(started) = serde_json::from_value(report["scan_started_at"].clone()) else {
        return false;
    };
    let processed =
        serde_json::from_value(report["scanned_at"].clone()).unwrap_or(record.processed_at);
    (
        record.scan_started_at,
        record.run_id.as_str(),
        record.processed_at,
    ) < (started, report["run_id"].as_str().unwrap_or(""), processed)
}

fn persisted_scan_key(entry: &Entry) -> Option<(String, String)> {
    let report = &entry.inspection["Ok"];
    Some((
        report["file_id"].as_str()?.to_owned(),
        report["run_id"].as_str()?.to_owned(),
    ))
}

fn scan_key(entry: &Entry) -> String {
    persisted_scan_key(entry).map_or_else(
        || format!("local:{}:{}", entry.row_id, entry.content_revision),
        |key| serde_json::to_string(&key).expect("문자열 식별자는 직렬화할 수 있습니다"),
    )
}

fn persisted_entry(record: &FileScanRecord) -> Entry {
    let path = PathBuf::from(&record.file_path);
    let mut file = record
        .metadata
        .get("file_info")
        .cloned()
        .and_then(|value| serde_json::from_value::<FileInfo>(value).ok())
        .unwrap_or_else(|| FileInfo {
            file_name: path
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .into_owned(),
            path: path.clone(),
            identity: None,
            folder: None,
            event: None,
            file_size_bytes: None,
            is_directory: Some(false),
        });
    file.path = path;
    file.file_name = file
        .path
        .file_name()
        .unwrap_or_default()
        .to_string_lossy()
        .into_owned();
    let processed = record.processed_at.timestamp_millis().max(0) as u64;
    Entry {
        row_id: format!("saved-{}", record.file_id),
        sequence: 0,
        timestamp_ms: record.scan_started_at.timestamp_millis().max(0) as u64,
        file,
        inspection: crate::persisted::inspection(record),
        inspection_timestamp_ms: Some(processed),
        inspection_pending: false,
        content_revision: 0,
    }
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .min(u64::MAX as u128) as u64
}

fn clean_path(path: &Path) -> String {
    let mut path = path.to_string_lossy().replace('\\', "/");
    if path
        .get(..8)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("//?/UNC/"))
    {
        path = format!("//{}", &path[8..]);
    } else if path.starts_with("//?/") || path.starts_with("/??/") {
        path = path[4..].to_owned();
    }
    let prefix = if path.starts_with("//") {
        "//"
    } else if path.starts_with('/') {
        "/"
    } else {
        ""
    };
    let mut components = Vec::new();
    for component in path
        .split('/')
        .filter(|part| !part.is_empty() && *part != ".")
    {
        if component == ".."
            && components
                .last()
                .is_some_and(|last: &&str| !last.ends_with(':') && *last != "..")
        {
            components.pop();
        } else {
            components.push(component);
        }
    }
    format!("{prefix}{}", components.join("/"))
}

pub(crate) fn path_key(path: &Path) -> String {
    let clean = clean_path(path);
    if clean.starts_with("//") || clean.as_bytes().get(1) == Some(&b':') {
        clean.to_lowercase()
    } else {
        clean
    }
}

fn is_within(path: &str, parent: &str) -> bool {
    path == parent
        || path
            .strip_prefix(parent)
            .is_some_and(|tail| parent.ends_with('/') || tail.starts_with('/'))
}

fn relocate(path: &Path, from: &Path, to: &Path) -> Option<PathBuf> {
    let key = path_key(path);
    let from_key = path_key(from);
    if !is_within(&key, &from_key) {
        return None;
    }

    let original = clean_path(path);
    let from_clean = clean_path(from);
    let from_components = from_clean
        .split('/')
        .filter(|part| !part.is_empty())
        .count();
    let suffix = original
        .split('/')
        .filter(|part| !part.is_empty())
        .skip(from_components)
        .collect::<Vec<_>>()
        .join("/");
    let destination = to.to_string_lossy();
    let separator = if destination.contains('\\') {
        '\\'
    } else {
        '/'
    };
    let mut result = destination.trim_end_matches(['\\', '/']).to_owned();
    if !suffix.is_empty() {
        result.push(separator);
        result.push_str(&suffix.replace('/', &separator.to_string()));
    }
    Some(PathBuf::from(result))
}

fn remove_metadata_paths(folder: &mut FolderInfo, deleted_key: &str) {
    if let Some(gitignore) = &mut folder.gitignore {
        for paths in [
            &mut gitignore.gitignore_files,
            &mut gitignore.ignored_files,
            &mut gitignore.untracked_ignored_files,
            &mut gitignore.sensitive_files,
        ] {
            paths.retain(|path| !is_within(&path_key(path), deleted_key));
        }
    }
}

fn rename_metadata_paths(folder: &mut FolderInfo, from: &Path, to: &Path) {
    if let Some(path) = relocate(&folder.folder_path, from, to) {
        folder.folder_path = path;
    }
    let group_key = path_key(&folder.folder_path);
    if let Some(gitignore) = &mut folder.gitignore {
        for paths in [
            &mut gitignore.gitignore_files,
            &mut gitignore.ignored_files,
            &mut gitignore.untracked_ignored_files,
            &mut gitignore.sensitive_files,
        ] {
            for path in paths.iter_mut() {
                if let Some(updated) = relocate(path, from, to) {
                    *path = updated;
                }
            }

            paths.retain(|path| is_within(&path_key(path), &group_key));
        }
    }
}
