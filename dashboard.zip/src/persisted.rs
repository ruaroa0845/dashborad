//저장된 JEV 판정을 대시보드의 검사 결과 형식 표기

use crate::scan_log::FileScanRecord;
use askfile::FileInfo;
use serde_json::{json, Value};
use std::path::Path;
use std::time::UNIX_EPOCH;

pub fn file_log_id(file: &FileInfo) -> Option<String> {
    file.identity.map(|identity| {
        format!(
            "{:X}_{:X}",
            identity.volume_serial_number, identity.file_reference_number
        )
    })
}

/// 파일 내용의 해시가 아닌 파일 내 데이터.
pub fn content_stamp(path: &Path) -> Option<Value> {
    let metadata = std::fs::metadata(path).ok()?;
    if !metadata.is_file() {
        return None;
    }
    let modified = metadata.modified().ok()?.duration_since(UNIX_EPOCH).ok()?;
    Some(json!({
        "length": metadata.len(),
        "modified_ns": modified.as_nanos().to_string(),
    }))
}

pub(crate) fn inspection(record: &FileScanRecord) -> Value {
    let regex_status = record
        .metadata
        .get("regex_status")
        .and_then(Value::as_str)
        .unwrap_or(if record.scan_status == "excluded" {
            "excluded"
        } else {
            "completed"
        });
    let jev_status = record
        .metadata
        .get("jev_status")
        .and_then(Value::as_str)
        .unwrap_or(&record.scan_status);
    let findings: Vec<_> = record
        .findings
        .iter()
        .map(|finding| {
            let mut value = finding.metadata.clone();
            let regex_severity = value
                .get("regex_severity")
                .or_else(|| value.get("severity"))
                .cloned()
                .unwrap_or(Value::Null);
            let context = value.get("context_masked").cloned().unwrap_or(Value::Null);

            value.insert("metadata".into(), json!(finding.metadata));
            value.insert("candidate_id".into(), json!(finding.candidate_id));
            value.insert("file_path".into(), json!(record.file_path));
            value.insert("line".into(), json!(finding.line_number));
            value.insert("line_number".into(), json!(finding.line_number));
            value.insert("status".into(), json!(finding.status));
            value.insert("regex_status".into(), json!(regex_status));
            value.insert("jev_status".into(), json!(finding.status));
            value.insert("secret_reality".into(), json!(finding.secret_reality));
            value.insert("secret_type".into(), json!(finding.secret_type));
            value.insert(
                "risk_level".into(),
                json!(finding.risk_level.as_deref().map(str::to_ascii_lowercase)),
            );
            value.insert("review_required".into(), json!(finding.review_required));
            value.insert("review_reasons".into(), json!(finding.review_reasons));
            value.insert("error_code".into(), json!(finding.error_code));
            value.insert("regex_severity".into(), regex_severity);
            value.insert(
                "severity".into(),
                json!(finding.risk_level.as_deref().map(str::to_ascii_lowercase)),
            );
            value.insert("context".into(), context);
            Value::Object(value)
        })
        .collect();
    json!({"Ok": {
        "status": record.scan_status,
        "regex_status": regex_status,
        "jev_status": jev_status,
        "reason": record.error_code,
        "error_code": record.error_code,
        "scanned_at": record.processed_at.to_rfc3339(),
        "scan_started_at": record.scan_started_at.to_rfc3339(),
        "file_id": record.file_id,
        "run_id": record.run_id,
        "metadata": record.metadata,
        "findings": findings,
    }})
}
