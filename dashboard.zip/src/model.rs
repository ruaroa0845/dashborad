//대시보드 화면 상태와 사용자 동작을 정의.

use serde_json::{json, Value};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum View {
    #[default]
    Files,
    Overview,
    Scans,
    Criteria,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Filters {
    pub folder: String,
    pub q: String,
    pub kind: String,
    pub severity: String,
    pub scan_status: String,
    pub file_status: String,
    pub category: String,
    pub sort: String,
    pub page_size: usize,
}

impl Default for Filters {
    fn default() -> Self {
        Self {
            folder: String::new(),
            q: String::new(),
            kind: String::new(),
            severity: String::new(),
            scan_status: String::new(),
            file_status: String::new(),
            category: String::new(),
            sort: String::new(),
            page_size: 20,
        }
    }
}

#[derive(Clone, Debug)]
pub enum Action {
    SetLocalAction {
        key: String,
        status: String,
        version: u64,
    },
    SetView(View),
    SetFilters(Filters),
    SelectFolder(String),
    ClearFolder,
    SelectFile(String),
    SelectScan(Value),
    CloseDetail,
    NextPage,
    PreviousPage,
    Refresh,
}

#[derive(Clone, Debug)]
pub struct UiModel {
    pub view: View,
    pub filters: Filters,
    pub cursor: Option<String>,
    pub page_number: usize,
    pub next_cursor: Option<String>,
    pub health: Value,
    pub files: Value,
    pub summary: Value,
    pub scans: Value,
    pub detail: Value,
    pub selected_file: Option<String>,
    pub loading: bool,
    pub detail_loading: bool,
    pub error: Option<String>,
    pub detail_error: Option<String>,
    pub revision: Option<String>,
    pub last_refresh_ms: Option<u64>,
}

impl Default for UiModel {
    fn default() -> Self {
        Self {
            view: View::Files,
            filters: Filters::default(),
            cursor: None,
            page_number: 1,
            next_cursor: None,
            health: Value::Null,
            files: json!({"items": [], "total": 0, "offset": 0, "next_cursor": null}),
            summary: Value::Null,
            scans: json!({"items": []}),
            detail: Value::Null,
            selected_file: None,
            loading: false,
            detail_loading: false,
            error: None,
            detail_error: None,
            revision: None,
            last_refresh_ms: None,
        }
    }
}
