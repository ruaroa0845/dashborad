pub mod api;
pub mod persisted;
pub mod scan_log;
pub mod state;
pub use state::{DashboardState, ScanTicket};

#[cfg(windows)]
pub mod gui;

#[cfg(windows)]
mod controller;
#[cfg(windows)]
mod model;
#[cfg(windows)]
mod view;

pub trait BackgroundTask: Send {
    /// UI 스레드를 차단하지 않고 정상적인 중지를 알림.
    fn request_stop(&self);
    /// 실행 중인 작업을 기다리지 않고 종료 대기를 완료할 수 있는지 반환.
    fn is_finished(&self) -> bool;
    /// 예기치 않은 메시지 루프 오류 등으로 `request_stop`을 먼저 호출하지 않았더라도 중지를 요청하고 남은 작업이 끝날 때까지 기다림.
    fn join(self: Box<Self>) -> Result<(), String>;
}
