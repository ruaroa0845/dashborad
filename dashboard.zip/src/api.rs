// 수집기의 실시간 파일 목록을 읽는 대시보드 조회 API

use crate::state::{path_key, Entry, FolderEntry, StateView};
use crate::DashboardState;
use askfile::{FileEvent, FolderInfo};
use serde_json::{json, Value};
use std::borrow::Cow;
use std::collections::{BTreeMap, BTreeSet};
use std::fmt::Write;
use std::path::Path;

const PREFIX: &str = "/api/v1/";
const MAX_PAGE_SIZE: usize = 1_000;

/// 응답 하나는 같은 버전을 읽으며, 직렬화.
pub fn request(state: &DashboardState, path: &str, method: &str, _body: Option<&str>) -> Value {
    if !method.eq_ignore_ascii_case("GET") {
        return error(
            405,
            "READ_ONLY",
            "검사 결과는 읽기 전용입니다. 조치 상태 변경은 지원하지 않습니다.",
        );
    }
    let (path, query) = path.split_once('?').unwrap_or((path, ""));
    let Some(route) = path.strip_prefix(PREFIX) else {
        return not_found();
    };
    let segments = route
        .trim_end_matches('/')
        .split('/')
        .map(|part| decode(part, false))
        .collect::<Result<Vec<_>, _>>();
    let query = parse_query(query);
    let (Ok(segments), Ok(query)) = (segments, query) else {
        return error(
            400,
            "INVALID_QUERY",
            "요청 주소의 문자 인코딩이 올바르지 않습니다.",
        );
    };
    let segments: Vec<_> = segments.iter().map(String::as_str).collect();
    state.read(|view| match segments.as_slice() {
        ["health"] => ok(json!({
            "mode": "live", "engine_connected": view.engine_connected,
            "engine_error": view.engine_error,
            "log_error": view.log_error, "initial_progress": view.initial_progress,
            "log_notice": view.log_notice,
            "candidate_progress": view.candidate_progress,
            "scan_progress": {"counts": scan_counts(&view)},
            "status": view.status, "message": view.message, "reason": view.message,
            "revision": view.revision.to_string(), "roots": view.roots,
            "summary": view.counters, "history": view.history,
            "data_updated_at": view.updated_at_ms, "result_received_at": view.result_received_at_ms,
        })),
        ["projects", project, "files"] if project_exists(&view, project) => {
            list(&view, project, &query)
        }
        ["projects", project, "files", id] if project_exists(&view, project) => {
            detail(&view, project, id)
        }
        ["projects", project, "dashboard", "summary"] if project_exists(&view, project) => {
            ok(summary(&view, project))
        }
        ["projects", project, "scans"] if project_exists(&view, project) => {
            ok(scans(&view, project))
        }
        _ => not_found(),
    })
}

/// Current files only: independent of table filters, pagination and historical events.
fn scan_counts(view: &StateView<'_>) -> Value {
    let mut counts =
        json!({"completed":0,"file_running":0,"jev_running":0,"failed":0,"review":0,"other":0});
    for entry in view
        .files
        .values()
        .filter(|entry| entry.file.is_directory == Some(false))
    {
        let key = match inspection_status(entry) {
            "completed" => "completed",
            "scanning" => "file_running",
            "awaiting_jev" => "jev_running",
            "failed" => "failed",
            "needs_review" => "review",
            _ => "other",
        };
        counts[key] = json!(counts[key].as_u64().unwrap_or(0) + 1);
    }
    counts
}

fn ok(body: Value) -> Value {
    json!({"status": 200, "body": body})
}

fn error(status: u16, code: &str, message: &str) -> Value {
    json!({"status": status, "body": {"error": {"code": code, "message": message}}})
}

fn not_found() -> Value {
    error(
        404,
        "RESOURCE_NOT_FOUND",
        "요청한 경로나 보존 중인 기록을 찾을 수 없습니다.",
    )
}

fn decode(value: &str, plus_as_space: bool) -> Result<String, ()> {
    let mut result = Vec::with_capacity(value.len());
    let mut source = value.as_bytes().iter().copied();
    while let Some(byte) = source.next() {
        match byte {
            b'%' => {
                let high = (source.next().ok_or(())? as char).to_digit(16).ok_or(())?;
                let low = (source.next().ok_or(())? as char).to_digit(16).ok_or(())?;
                result.push((high * 16 + low) as u8);
            }
            b'+' if plus_as_space => result.push(b' '),
            _ => result.push(byte),
        }
    }
    String::from_utf8(result).map_err(|_| ())
}

fn parse_query(query: &str) -> Result<BTreeMap<String, String>, ()> {
    query
        .split('&')
        .filter(|part| !part.is_empty())
        .map(|part| {
            let (key, value) = part.split_once('=').unwrap_or((part, ""));
            Ok((decode(key, true)?, decode(value, true)?))
        })
        .collect()
}

// 정규화 경로를 16진수로 표현해 해시 충돌 없이 원래 식별자를 보존합니다.
fn path_id(prefix: &str, key: &str) -> String {
    let mut id = String::with_capacity(prefix.len() + key.len() * 2);
    id.push_str(prefix);
    for byte in key.bytes() {
        write!(&mut id, "{byte:02x}").expect("writing to String cannot fail");
    }
    id
}

fn project_id(folder: Option<&FolderInfo>) -> String {
    folder.map_or_else(
        || "ungrouped".into(),
        |folder| path_id("project-", &path_key(&folder.folder_path)),
    )
}

fn project_exists(view: &StateView<'_>, project: &str) -> bool {
    project == "all"
        || project == "ungrouped"
        || view
            .folders
            .values()
            .any(|folder| project_id(Some(&folder.info)) == project)
        || view
            .events
            .iter()
            .any(|entry| project_id(entry.file.folder.as_ref()) == project)
}

enum Row<'a> {
    File {
        entry: &'a Entry,
        deleted: bool,
    },
    Folder {
        key: &'a str,
        folder: &'a FolderEntry,
    },
}

impl<'a> Row<'a> {
    fn id(&self) -> Cow<'a, str> {
        match self {
            Self::File { entry, .. } => Cow::Borrowed(&entry.row_id),
            Self::Folder { key, .. } => Cow::Owned(path_id("folder-", key)),
        }
    }

    fn path(&self) -> &'a Path {
        match self {
            Self::File { entry, .. } => &entry.file.path,
            Self::Folder { folder, .. } => &folder.info.folder_path,
        }
    }

    fn name(&self) -> Cow<'a, str> {
        match self {
            Self::File { entry, .. } => Cow::Borrowed(&entry.file.file_name),
            Self::Folder { folder, .. } => Cow::Owned(file_name(&folder.info.folder_path)),
        }
    }

    fn directory(&self) -> Option<bool> {
        match self {
            Self::File { entry, .. } => entry.file.is_directory,
            Self::Folder { .. } => Some(true),
        }
    }

    fn deleted(&self) -> bool {
        matches!(self, Self::File { deleted: true, .. })
    }

    fn folder(&self, view: &StateView<'a>) -> Option<&'a FolderInfo> {
        match self {
            Self::File { entry, deleted } => entry.file.folder.as_ref().map(|folder| {
                if !deleted {
                    if let Some(current) = view.folders.get(&path_key(&folder.folder_path)) {
                        return &current.info;
                    }
                }
                folder
            }),
            Self::Folder { folder, .. } => Some(&folder.info),
        }
    }

    fn in_project(&self, view: &StateView<'a>, project: &str) -> bool {
        project == "all" || project_id(self.folder(view)) == project
    }

    fn scan_status(&self) -> &'static str {
        match self {
            Self::File { entry, .. } if entry.file.is_directory != Some(true) => {
                inspection_status(entry)
            }
            _ => "not_applicable",
        }
    }

    fn findings(&self) -> &[Value] {
        match self {
            Self::File { entry, .. } if entry.file.is_directory != Some(true) => {
                candidate_records(entry)
            }
            _ => &[],
        }
    }

    fn highest_severity(&self) -> Option<&str> {
        self.findings()
            .iter()
            .filter_map(finding_severity)
            .min_by_key(|severity| severity_rank(Some(severity)))
    }
}

fn file_name(path: &Path) -> String {
    path.to_string_lossy()
        .trim_end_matches(['/', '\\'])
        .rsplit(['/', '\\'])
        .next()
        .unwrap_or_default()
        .to_owned()
}

fn rows<'a>(view: &StateView<'a>, include_deleted: bool) -> Vec<Row<'a>> {
    let mut rows: Vec<_> = view
        .files
        .values()
        .map(|entry| Row::File {
            entry,
            deleted: false,
        })
        .collect();
    rows.extend(view.folders.iter().filter_map(|(key, folder)| {
        (!view.files.contains_key(key)).then_some(Row::Folder { key, folder })
    }));
    if include_deleted {
        let mut seen = BTreeSet::new();
        rows.extend(view.events.iter().rev().filter_map(|entry| {
            (matches!(entry.file.event, Some(FileEvent::Deleted))
                && !view.row_paths.contains_key(&entry.row_id)
                && seen.insert(entry.row_id.as_str()))
            .then_some(Row::File {
                entry,
                deleted: true,
            })
        }));
    }
    rows
}

fn query<'a>(params: &'a BTreeMap<String, String>, key: &str) -> &'a str {
    params.get(key).map(String::as_str).unwrap_or("")
}

fn is_descendant_file(row: &Row<'_>, folder: &str) -> bool {
    if row.directory() == Some(true) {
        return false;
    }
    let path = path_key(row.path());
    path.strip_prefix(folder)
        .is_some_and(|tail| !tail.is_empty() && (folder.ends_with('/') || tail.starts_with('/')))
}

fn list(view: &StateView<'_>, project: &str, params: &BTreeMap<String, String>) -> Value {
    let cursor = query(params, "cursor");
    let Ok(offset) = (if cursor.is_empty() { "0" } else { cursor }).parse::<usize>() else {
        return error(
            400,
            "INVALID_CURSOR",
            "목록 페이지 위치가 올바르지 않습니다.",
        );
    };
    let limit = match query(params, "limit") {
        "" => 20,
        value => match value.parse::<usize>() {
            Ok(value) => value.clamp(1, MAX_PAGE_SIZE),
            Err(_) => return error(400, "INVALID_QUERY", "페이지 크기는 정수여야 합니다."),
        },
    };
    let needle = query(params, "q").replace('\\', "/").to_lowercase();
    let folder = query(params, "folder");
    let folder = (!folder.is_empty()).then(|| path_key(Path::new(folder)));
    let kind = query(params, "kind");
    let status = query(params, "file_status");
    let scan = query(params, "scan_status");
    let severity = query(params, "severity");
    let category = query(params, "category");
    let finding_status_filter = query(params, "finding_status");
    let reality = query(params, "secret_reality");
    let review = query(params, "review_required");
    let mut selected: Vec<_> = rows(view, status != "present")
        .into_iter()
        .filter(|row| {
            row.in_project(view, project)
                && folder
                    .as_ref()
                    .is_none_or(|folder| is_descendant_file(row, folder))
                && (severity.is_empty()
                    || row.highest_severity() == Some(severity)
                    || (severity == "unassessed" && row.findings().iter().any(unassessed)))
                && (category.is_empty()
                    || row
                        .findings()
                        .iter()
                        .any(|finding| finding_category(finding) == category))
                && ((finding_status_filter.is_empty() && reality.is_empty() && review.is_empty())
                    || row.findings().iter().any(|finding| {
                        (finding_status_filter.is_empty()
                            || finding_status(finding) == finding_status_filter)
                            && (reality.is_empty()
                                || finding["secret_reality"].as_str() == Some(reality))
                            && match review {
                                "" => true,
                                "true" => needs_review(finding),
                                "false" => !needs_review(finding),
                                _ => false,
                            }
                    }))
                && match kind {
                    "" => true,
                    "file" => row.directory() == Some(false),
                    "folder" => row.directory() == Some(true),
                    _ => false,
                }
                && match status {
                    "" => true,
                    "present" => !row.deleted(),
                    "deleted" => row.deleted(),
                    _ => false,
                }
                && (scan.is_empty() || scan == row.scan_status())
                && (needle.is_empty()
                    || row
                        .path()
                        .to_string_lossy()
                        .replace('\\', "/")
                        .to_lowercase()
                        .contains(&needle)
                    || row.name().to_lowercase().contains(&needle))
        })
        .collect();
    match query(params, "sort") {
        "name" => selected.sort_by_cached_key(|row| {
            (
                row.name().to_lowercase(),
                path_key(row.path()),
                row.deleted(),
            )
        }),
        "risk" => selected.sort_by_cached_key(|row| {
            (
                severity_rank(row.highest_severity()),
                path_key(row.path()),
                row.deleted(),
            )
        }),
        _ => selected.sort_by_cached_key(|row| (path_key(row.path()), row.deleted())),
    }
    let total = selected.len();
    let next = offset.saturating_add(limit);
    let items: Vec<_> = selected
        .iter()
        .skip(offset)
        .take(limit)
        .map(|row| serialize_row(view, row))
        .collect();
    ok(json!({
        "items": items, "total": total, "offset": offset,
        "next_cursor": (next < total).then(|| next.to_string()),
        "revision": view.revision.to_string(), "data_updated_at": view.updated_at_ms, "result_received_at": view.result_received_at_ms,
        "history": view.history,
    }))
}

fn detail(view: &StateView<'_>, project: &str, id: &str) -> Value {
    // 파일 ID를 사용해 상세 조회에서 전체 목록을 탐색하지 않습니다.
    if let Some(path) = view.row_paths.get(id) {
        if let Some(entry) = view.files.get(path) {
            let row = Row::File {
                entry,
                deleted: false,
            };
            if row.in_project(view, project) {
                return ok(serialize_row(view, &row));
            }
        }
    }
    for row in rows(view, true) {
        if row.id() == id && row.in_project(view, project) {
            return ok(serialize_row(view, &row));
        }
    }
    not_found()
}

fn inspection_status(entry: &Entry) -> &'static str {
    if entry.inspection["Ok"]["sdk_changed_since_scan"] == true {
        return "scanning";
    }
    if entry.inspection["Ok"]["status"] == "awaiting_jev" {
        "awaiting_jev"
    } else if entry.inspection_pending {
        "scanning"
    } else if entry.inspection.get("Err").is_some() {
        "failed"
    } else {
        match entry.inspection["Ok"]["status"].as_str() {
            Some("completed") => "completed",
            Some("awaiting_jev") => "awaiting_jev",
            Some("needs_review") => "needs_review",
            Some("excluded") => "excluded",
            Some("failed") => "failed",
            // 정규식 정책으로 건너뛴 결과는 기존 미검사 표시를 유지합니다.
            _ => "not_scanned",
        }
    }
}

fn candidate_records(entry: &Entry) -> &[Value] {
    entry.inspection["Ok"]["findings"]
        .as_array()
        .map(Vec::as_slice)
        .unwrap_or_default()
}

fn severity_rank(severity: Option<&str>) -> u8 {
    match severity {
        Some("high") => 0,
        Some("medium") => 1,
        Some("low") => 2,
        _ => 3,
    }
}

fn has_decision(candidate: &Value) -> bool {
    finding_status(candidate) != "awaiting_jev"
        && (candidate.get("secret_reality").is_some()
            || candidate.get("risk_level").is_some()
            || candidate.get("review_required").is_some())
}

fn finding_status(candidate: &Value) -> &str {
    candidate["status"].as_str().unwrap_or("unclassified")
}

fn needs_review(candidate: &Value) -> bool {
    candidate["review_required"] == true || finding_status(candidate) == "needs_review"
}

fn non_sensitive(candidate: &Value) -> bool {
    finding_status(candidate) == "classified"
        && !needs_review(candidate)
        && matches!(
            candidate["secret_reality"].as_str(),
            Some("likely_test" | "placeholder")
        )
}

fn finding_severity(candidate: &Value) -> Option<&'static str> {
    if !has_decision(candidate)
        || non_sensitive(candidate)
        || matches!(finding_status(candidate), "excluded" | "awaiting_jev")
    {
        return None;
    }
    let severity = &candidate["risk_level"];
    match severity.as_str()? {
        "High" | "high" => Some("high"),
        "Medium" | "medium" => Some("medium"),
        "Low" | "low" => Some("low"),
        _ => None,
    }
}

fn active_finding(candidate: &Value) -> bool {
    if finding_status(candidate) == "awaiting_jev" {
        return false;
    }
    if !has_decision(candidate) {
        return false;
    }
    finding_status(candidate) == "classified"
        && candidate["secret_reality"] == "likely_real"
        && !needs_review(candidate)
        && finding_severity(candidate).is_some()
}

fn unassessed(candidate: &Value) -> bool {
    (has_decision(candidate) || finding_status(candidate) == "awaiting_jev")
        && !non_sensitive(candidate)
        && finding_status(candidate) != "excluded"
        && finding_severity(candidate).is_none()
}

fn finding_category(candidate: &Value) -> &str {
    match candidate["secret_type"].as_str() {
        Some(
            "api_key" | "access_token" | "ssh_key" | "x509_certificate" | "connection_string"
            | "db_password" | "other_secret_key",
        ) => "secret",
        Some(
            "resident_registration_number"
            | "phone_number"
            | "email_address"
            | "bank_account"
            | "password",
        ) => "pii",
        Some("des" | "rc4" | "md5" | "sha1" | "ecb") => "weak_crypto",
        _ => category_key(&candidate["category"]),
    }
}

fn category_key(category: &Value) -> &str {
    match category.as_str().unwrap_or("unknown") {
        "인증 및 비밀정보" | "secret" => "secret",
        "개인정보" | "pii" => "pii",
        "취약한 암호화 알고리즘" | "weak_crypto" => "weak_crypto",
        "비구조화 로그 & 환경 파일" | "environment" => "environment",
        other => other,
    }
}

fn inspection_time(entry: &Entry) -> Value {
    entry.inspection["Ok"]["scanned_at"].as_str().map_or_else(
        || json!(entry.inspection_timestamp_ms),
        |value| json!(value),
    )
}

fn inspection_reason(entry: &Entry) -> Value {
    entry
        .inspection
        .get("Err")
        .cloned()
        .unwrap_or_else(|| entry.inspection["Ok"]["reason"].clone())
}

fn local_action_key(entry: &Entry, candidate: &Value, fallback: &str) -> String {
    let report = &entry.inspection["Ok"];
    let file = report["file_id"].as_str().unwrap_or(&entry.row_id);
    let run = report["run_id"]
        .as_str()
        .map(str::to_owned)
        .unwrap_or_else(|| {
            format!(
                "{}:{}",
                entry.content_revision,
                entry.inspection_timestamp_ms.unwrap_or(0)
            )
        });
    serde_json::to_string(&(
        file,
        run,
        candidate["candidate_id"].as_str().unwrap_or(fallback),
    ))
    .unwrap()
}

fn serialize_finding(
    view: &StateView<'_>,
    row: &Row<'_>,
    entry: &Entry,
    candidate: &Value,
    index: usize,
) -> Value {
    let nonempty = |key: &str| candidate[key].as_str().filter(|value| !value.is_empty());
    let id = nonempty("finding_key")
        .or_else(|| nonempty("candidate_id"))
        .map(str::to_owned)
        .unwrap_or_else(|| format!("{}-candidate-{index}", row.id()));
    let snippet = nonempty("line_masked").or_else(|| nonempty("value_masked"));
    let action_key = local_action_key(entry, candidate, &id);
    let action = view.local_actions.get(&action_key);

    json!({
        "finding_id": id, "file_id": row.id(),
        "action_key": action_key,
        "local_status": action.map(|v| &v["status"]).cloned().unwrap_or(json!("open")),
        "local_version": action.and_then(|v| v["version"].as_u64()).unwrap_or(0),
        "local_history": action.map(|v| &v["history"]).cloned().unwrap_or(json!([])),
        "run_id": entry.inspection["Ok"]["run_id"], "file_path": row.path(),
        "candidate_id": candidate["candidate_id"], "rule_id": candidate["rule_id"],
        "title": nonempty("rule_name").or_else(|| nonempty("secret_type")).or_else(|| nonempty("rule_id")).unwrap_or("탐지 후보"),
        "category": finding_category(candidate),
        "severity": if has_decision(candidate) { finding_severity(candidate) } else { None }, "status": finding_status(candidate), "read_only": true,
        "decision_source": if has_decision(candidate) { "jev" } else { "regex" },
        "secret_reality": candidate["secret_reality"], "secret_type": candidate["secret_type"],
        "risk_level": if has_decision(candidate) { finding_severity(candidate) } else { None },
        "regex_severity": candidate.get("regex_severity").unwrap_or(&candidate["severity"]),
        "regex_status": candidate.get("regex_status").unwrap_or(&entry.inspection["Ok"]["regex_status"]),
        "jev_status": candidate.get("jev_status").unwrap_or(&entry.inspection["Ok"]["jev_status"]),
        "review_required": needs_review(candidate), "review_reasons": candidate["review_reasons"],
        "error_code": candidate["error_code"], "active": active_finding(candidate),
        "line": candidate["line"], "column": candidate["column"],
        "end_line": candidate["end_line"], "end_column": candidate["end_column"],
        "masked_snippet": snippet, "value_masked": candidate["value_masked"],
        "line_masked": candidate["line_masked"],
        "context": candidate["context"],
        "detected_at": candidate.get("scanned_at").cloned().unwrap_or_else(|| inspection_time(entry)),
        "engine_version": candidate["engine_version"],
    })
}

fn serialize_row(view: &StateView<'_>, row: &Row<'_>) -> Value {
    let folder = row.folder(view);
    let (mut value, timestamp, sequence) = match row {
        Row::File { entry, .. } => (
            serde_json::to_value(&entry.file).expect("FileInfo serialization cannot fail"),
            entry.timestamp_ms,
            entry.sequence,
        ),
        Row::Folder { folder, .. } => (
            json!({"file_name": row.name(), "path": row.path(), "identity": null, "event": null,
                "file_size_bytes": null, "is_directory": true, "synthetic_folder": true}),
            folder.timestamp_ms,
            folder.sequence,
        ),
    };
    if let Row::File { entry, .. } = row {
        // 자바스크립트 숫자는 모든 NTFS 파일 참조 번호를 정확히 표현하지 못합니다.
        // 공용 Rust 파일 정보는 유지하고 API에서 정확한 문자열로 전달합니다.
        value["identity"] = entry.file.identity.map_or(Value::Null, |identity| {
            json!({
                "volume_serial_number": format!("0x{:08x}", identity.volume_serial_number),
                "file_reference_number": format!("0x{:016x}", identity.file_reference_number),
            })
        });
        value["reason"] = inspection_reason(entry);
        value["last_scanned_at"] = inspection_time(entry);
        value["regex_status"] = entry.inspection["Ok"]["regex_status"].clone();
        value["jev_status"] = entry.inspection["Ok"]["jev_status"].clone();
        value["changed_since_scan"] = json!(
            entry.inspection["Ok"]["sdk_changed_since_scan"] == true
                || entry.inspection_pending
                    && !entry.inspection.is_null()
                    && entry.inspection["Ok"]["status"] != "awaiting_jev"
        );
        value["findings"] = json!(row
            .findings()
            .iter()
            .enumerate()
            .map(|(index, candidate)| serialize_finding(view, row, entry, candidate, index))
            .collect::<Vec<_>>());
    } else {
        value["reason"] = Value::Null;
        value["last_scanned_at"] = Value::Null;
        value["changed_since_scan"] = json!(false);
        value["findings"] = json!([]);
    }
    value["file_id"] = json!(row.id());
    value["project_id"] = json!(project_id(folder));
    value["folder"] = json!(folder);
    value["file_status"] = json!(if row.deleted() { "deleted" } else { "present" });
    value["last_known_path"] = if row.deleted() {
        json!(row.path())
    } else {
        Value::Null
    };
    value["deleted_at"] = if row.deleted() {
        json!(timestamp)
    } else {
        Value::Null
    };
    // 파일 정보의 시각 검사 시작 시간.
    value["modified_at"] = Value::Null;
    value["observed_at"] = json!(timestamp);
    value["sequence"] = json!(sequence.to_string());
    value["scan_status"] = json!(row.scan_status());
    value["finding_count"] = json!(row.findings().len());
    value["open_finding_count"] = json!(row
        .findings()
        .iter()
        .filter(|finding| active_finding(finding))
        .count());
    value["review_required_count"] = json!(row
        .findings()
        .iter()
        .filter(|finding| needs_review(finding))
        .count());
    value["non_sensitive_count"] = json!(row
        .findings()
        .iter()
        .filter(|finding| non_sensitive(finding))
        .count());
    value["highest_severity"] = json!(row.highest_severity());
    value["final_severity"] = json!(row
        .findings()
        .iter()
        .filter(|f| has_decision(f) && finding_status(f) == "classified")
        .filter_map(finding_severity)
        .min_by_key(|risk| severity_rank(Some(risk))));
    value["categories"] = json!(row
        .findings()
        .iter()
        .map(finding_category)
        .collect::<BTreeSet<_>>());
    value["findings_read_only"] = json!(true);
    value["revision"] = json!(view.revision.to_string());
    value
}

fn summary(view: &StateView<'_>, project: &str) -> Value {
    let selected: Vec<_> = rows(view, false)
        .into_iter()
        .filter(|row| row.in_project(view, project))
        .collect();
    let mut severity = BTreeMap::from([("high", 0usize), ("medium", 0), ("low", 0)]);
    let mut categories = BTreeMap::from([
        ("secret", 0usize),
        ("pii", 0),
        ("weak_crypto", 0),
        ("environment", 0),
    ]);
    let mut recent = Vec::new();
    let mut statuses = BTreeMap::<&str, usize>::new();
    let mut active_count = 0;
    let mut unresolved_count = 0;
    let mut review_count = 0;
    let mut non_sensitive_count = 0;
    let mut unassessed_count = 0;
    let mut legacy_count = 0;
    let mut awaiting_count = 0;
    let mut test_count = 0;
    let mut placeholder_count = 0;
    for row in &selected {
        if let Row::File { entry, .. } = row {
            for (index, candidate) in row.findings().iter().enumerate() {
                *statuses.entry(finding_status(candidate)).or_default() += 1;
                review_count += usize::from(needs_review(candidate));
                awaiting_count += usize::from(finding_status(candidate) == "awaiting_jev");
                test_count += usize::from(
                    non_sensitive(candidate) && candidate["secret_reality"] == "likely_test",
                );
                placeholder_count += usize::from(
                    non_sensitive(candidate) && candidate["secret_reality"] == "placeholder",
                );
                non_sensitive_count += usize::from(non_sensitive(candidate));
                unassessed_count += usize::from(unassessed(candidate));
                legacy_count += usize::from(
                    !has_decision(candidate) && finding_status(candidate) != "awaiting_jev",
                );
                if active_finding(candidate) {
                    active_count += 1;
                    let rendered = serialize_finding(view, row, entry, candidate, index);
                    if matches!(
                        rendered["local_status"].as_str(),
                        Some("open" | "in_progress")
                    ) {
                        unresolved_count += 1;
                    }
                    if let Some(count) =
                        finding_severity(candidate).and_then(|key| severity.get_mut(key))
                    {
                        *count += 1;
                    }
                    *categories.entry(finding_category(candidate)).or_default() += 1;
                }
                recent.push((
                    entry.inspection_timestamp_ms.unwrap_or(0),
                    row,
                    entry,
                    candidate,
                    index,
                ));
            }
        }
    }
    let finding_count = recent.len();
    recent.sort_by_key(|item| std::cmp::Reverse(item.0));
    let recent: Vec<_> = recent
        .into_iter()
        .take(6)
        .map(|(_, row, entry, candidate, index)| {
            serialize_finding(view, row, entry, candidate, index)
        })
        .collect();
    json!({
        "file_count": selected.iter().filter(|row| row.directory() == Some(false)).count(),
        "folder_count": selected.iter().filter(|row| row.directory() == Some(true)).count(),
        "unknown_kind_count": selected.iter().filter(|row| row.directory().is_none()).count(),
        "unscanned_count": selected.iter().filter(|row| row.directory() == Some(false) && row.scan_status() != "completed").count(),
        "active_findings": active_count, "unresolved_findings": unresolved_count, "candidate_count": finding_count,
        "review_required_count": review_count, "non_sensitive_count": non_sensitive_count,
        "awaiting_jev_count": awaiting_count, "likely_test_count": test_count, "placeholder_count": placeholder_count,
        "scanning_file_count": selected.iter().filter(|row| matches!(row.scan_status(), "scanning"|"awaiting_jev")).count(),
        "unassessed_count": unassessed_count, "legacy_candidate_count": legacy_count,
        "severity": severity, "categories": categories,
        "statuses": statuses,
        "recent_findings": recent, "engine_connected": view.engine_connected,
        "engine_error": view.engine_error, "findings_read_only": true,
        "revision": view.revision.to_string(), "data_updated_at": view.updated_at_ms, "result_received_at": view.result_received_at_ms,
    })
}

fn scans(view: &StateView<'_>, project: &str) -> Value {
    let mut items: Vec<_> = view
        .scan_history
        .iter()
        .rev()
        .filter(|entry| !entry.inspection.is_null())
        .filter(|entry| project == "all" || project_id(entry.file.folder.as_ref()) == project)
        .map(|entry| {
            let report = &entry.inspection["Ok"];
            let run_id = report["run_id"].as_str();
            let scan_id = run_id.map(str::to_owned)
                .unwrap_or_else(|| format!("inspection-{}-{}", entry.sequence, entry.content_revision));
            let started_at = report["scan_started_at"].as_str()
                .map_or(Value::Null, |time| json!(time));
            let mut snapshot = serialize_row(view, &Row::File {entry, deleted: false});
            snapshot["folder"] = json!(entry.file.folder);
            snapshot["history_snapshot"] = json!(true);
            snapshot["history_key"] = json!(format!("{}:{}:{}", entry.row_id, scan_id, inspection_time(entry)));
            snapshot["scan_id"] = json!(scan_id);
            snapshot["started_at"] = started_at.clone();
            let confirmed = candidate_records(entry).iter().filter(|f| active_finding(f)).count();
            let trigger = match &entry.file.event {
                Some(askfile::FileEvent::Created) => "생성",
                Some(askfile::FileEvent::Modified) => "수정",
                Some(askfile::FileEvent::Renamed {..}) => "이름 변경",
                Some(askfile::FileEvent::Deleted) => "삭제",
                Some(_) => "기타 변경",
                None => "초기 / 변경 정보 미제공",
            };
            snapshot["trigger"] = json!(trigger);
            json!({
                "_sort_time": entry.inspection_timestamp_ms.unwrap_or(entry.timestamp_ms),
                "detail": snapshot, "file_name": entry.file.file_name, "trigger": trigger,
                "confirmed_count": confirmed,
                "scan_id": scan_id, "run_id": run_id,
                "project_id": project_id(entry.file.folder.as_ref()),
                "file_id": entry.row_id, "path": entry.file.path,
                "started_at": started_at, "completed_at": inspection_time(entry), "observed_at": entry.timestamp_ms,
                "status": inspection_status(entry), "reason": inspection_reason(entry),
                "regex_status": report["regex_status"], "jev_status": report["jev_status"],
                "file_count": 1, "finding_count": candidate_records(entry).len(),
            })
        })
        .collect();
    items.sort_by_key(|row| std::cmp::Reverse(row["_sort_time"].as_u64().unwrap_or(0)));
    for row in &mut items {
        row.as_object_mut().unwrap().remove("_sort_time");
    }
    json!({
        "items": items,
        "history": {
            "capacity": view.history["capacity"], "retained": view.scan_history.len(),
            "dropped": view.scan_history_total.saturating_sub(view.scan_history.len() as u64),
        },
        "revision": view.revision.to_string(), "data_updated_at": view.updated_at_ms, "result_received_at": view.result_received_at_ms,
    })
}
