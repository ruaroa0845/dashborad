//! Dashboard-owned JSON contract. No model execution or JEV source dependency.
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};
use std::{
    collections::BTreeMap,
    fs, io,
    path::{Path, PathBuf},
};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Finding {
    pub candidate_id: String,
    #[serde(default)]
    pub line_number: Option<u64>,
    #[serde(default)]
    pub status: String,
    #[serde(default)]
    pub secret_reality: Option<String>,
    #[serde(default)]
    pub secret_type: Option<String>,
    #[serde(default)]
    pub risk_level: Option<String>,
    #[serde(default)]
    pub review_required: bool,
    #[serde(default)]
    pub review_reasons: Vec<String>,
    #[serde(default)]
    pub error_code: Option<String>,
    #[serde(default)]
    pub metadata: Map<String, Value>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FileScanRecord {
    pub file_id: String,
    pub run_id: String,
    pub file_path: String,
    pub scan_started_at: DateTime<Utc>,
    pub processed_at: DateTime<Utc>,
    pub scan_status: String,
    #[serde(default)]
    pub error_code: Option<String>,
    #[serde(default)]
    pub findings: Vec<Finding>,
    #[serde(default)]
    pub metadata: Map<String, Value>,
}
pub type RegexScanRecord = FileScanRecord;
impl FileScanRecord {
    pub fn dashboard_record(&self) -> Self {
        let mut r = self.clone();
        let pending = r.scan_status == "completed" && !r.findings.is_empty();
        r.metadata
            .insert("regex_status".into(), json!(r.scan_status));
        if pending {
            r.scan_status = "awaiting_jev".into();
        }
        r.metadata.insert(
            "jev_status".into(),
            json!(if pending {
                "awaiting_jev"
            } else {
                "not_required"
            }),
        );
        for f in &mut r.findings {
            f.status = if pending { "awaiting_jev" } else { "excluded" }.into();
            f.secret_reality = None;
            f.secret_type = None;
            f.risk_level = None;
            f.review_required = false;
            f.review_reasons.clear();
            f.error_code = None;
        }
        r
    }
}
pub fn normalize_file_id(id: &str) -> Result<String, String> {
    let (a, b) = id.split_once('_').ok_or("INVALID_FILE_ID")?;
    let a = u32::from_str_radix(a, 16).map_err(|_| "INVALID_VOLUME_ID")?;
    let b = u64::from_str_radix(b, 16).map_err(|_| "INVALID_FILE_REFERENCE")?;
    Ok(format!("{a:X}_{b:X}"))
}
fn invalid(e: impl std::fmt::Display) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, e.to_string())
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ScanStoreFingerprint(Vec<(PathBuf, Vec<u8>)>);
#[derive(Clone)]
pub struct FileScanStore {
    root: PathBuf,
}
#[derive(Default)]
pub struct DashboardRecords {
    pub latest: BTreeMap<String, FileScanRecord>,
    pub history: Vec<FileScanRecord>,
    pub total: u64,
    pub errors: Vec<String>,
}
#[derive(Default)]
pub struct Recovery {
    pub repaired: usize,
    pub warnings: Vec<String>,
    pub errors: Vec<String>,
}
impl FileScanStore {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }
    pub fn root(&self) -> &Path {
        &self.root
    }
    pub fn latest_path(&self, id: &str) -> io::Result<PathBuf> {
        Ok(self
            .root
            .join("jev/latest")
            .join(format!("{}.json", normalize_file_id(id).map_err(invalid)?)))
    }
    pub fn fingerprint(&self) -> io::Result<ScanStoreFingerprint> {
        fn walk(dir: &Path, out: &mut Vec<(PathBuf, Vec<u8>)>) -> io::Result<()> {
            if !dir.exists() {
                return Ok(());
            }
            for entry in fs::read_dir(dir)? {
                let entry = entry?;
                let kind = entry.file_type()?;
                let path = entry.path();
                if kind.is_symlink() {
                    continue;
                }
                if kind.is_dir() {
                    walk(&path, out)?
                } else if path
                    .extension()
                    .is_some_and(|s| s == "json" || s == "jsonl")
                {
                    out.push((path.clone(), fs::read(path)?));
                }
            }
            Ok(())
        }
        let mut entries = Vec::new();
        for stage in ["regex", "jev"] {
            walk(&self.root.join(stage), &mut entries)?;
        }
        entries.sort_by(|a, b| a.0.cmp(&b.0));
        Ok(ScanStoreFingerprint(entries))
    }
    pub fn read_dashboard(&self, fp: &ScanStoreFingerprint, capacity: usize) -> DashboardRecords {
        let mut out = DashboardRecords::default();
        let mut regex: BTreeMap<(String, String), FileScanRecord> = BTreeMap::new();
        let mut jev: BTreeMap<(String, String), FileScanRecord> = BTreeMap::new();
        let records = fp.0.iter().flat_map(|(path, bytes)| {
            if path.extension().is_some_and(|ext| ext == "jsonl") {
                bytes
                    .split(|byte| *byte == b'\n')
                    .filter(|line| !line.iter().all(u8::is_ascii_whitespace))
                    .map(|line| (path, line))
                    .collect::<Vec<_>>()
            } else {
                vec![(path, bytes.as_slice())]
            }
        });
        for (path, bytes) in records {
            let record = serde_json::from_slice::<FileScanRecord>(bytes).and_then(|mut r| {
                r.file_id = normalize_file_id(&r.file_id).map_err(serde::de::Error::custom)?;
                let mut seen = std::collections::HashSet::new();
                if r.findings.iter().any(|f| !seen.insert(&f.candidate_id)) {
                    return Err(serde::de::Error::custom("duplicate candidate_id"));
                }
                Ok(r)
            });
            match record {
                Ok(r) => {
                    if path.parent().is_some_and(|p| p.ends_with("latest"))
                        && path
                            .file_stem()
                            .and_then(|s| s.to_str())
                            .and_then(|s| normalize_file_id(s).ok())
                            .as_ref()
                            != Some(&r.file_id)
                    {
                        out.errors
                            .push(format!("file_id mismatch: {}", path.display()));
                        continue;
                    }
                    let target = if path.starts_with(self.root.join("regex")) {
                        &mut regex
                    } else {
                        &mut jev
                    };
                    let key = (r.file_id.clone(), r.run_id.clone());
                    if target
                        .get(&key)
                        .is_none_or(|old| r.processed_at >= old.processed_at)
                    {
                        target.insert(key, r);
                    }
                }
                Err(e) => out.errors.push(format!("{}: {e}", path.display())),
            }
        }
        for (key, r) in regex {
            let combined = if let Some(mut j) = jev.remove(&key) {
                // Identity + run + candidate are the only join keys; regex severity is never a final risk.
                j.metadata
                    .entry("regex_status")
                    .or_insert(json!(r.scan_status));
                for rf in r.findings {
                    if let Some(jf) = j
                        .findings
                        .iter_mut()
                        .find(|f| f.candidate_id == rf.candidate_id)
                    {
                        let mut metadata = rf.metadata;
                        metadata.extend(jf.metadata.clone());
                        jf.metadata = metadata;
                        if jf.line_number.is_none() {
                            jf.line_number = rf.line_number;
                        }
                    } else if !matches!(j.scan_status.as_str(), "excluded" | "failed" | "error") {
                        let mut f = rf;
                        f.status = "needs_review".into();
                        f.risk_level = None;
                        f.secret_reality = None;
                        f.secret_type = None;
                        f.review_required = true;
                        f.review_reasons = vec!["JEV_RESULT_MISSING".into()];
                        f.error_code = Some("JEV_RESULT_MISSING".into());
                        j.findings.push(f);
                        j.scan_status = "needs_review".into();
                    }
                }
                j
            } else {
                r.dashboard_record()
            };
            out.history.push(combined);
        }
        out.history.extend(jev.into_values());
        out.history.sort_by(|a, b| {
            b.scan_started_at
                .cmp(&a.scan_started_at)
                .then(b.processed_at.cmp(&a.processed_at))
        });
        for r in &out.history {
            out.latest
                .entry(r.file_id.clone())
                .or_insert_with(|| r.clone());
        }
        out.total = out.history.len() as u64;
        out.history.truncate(capacity);
        out
    }
    pub fn read_latest(&self, id: &str) -> io::Result<Option<FileScanRecord>> {
        let fp = self.fingerprint()?;
        let data = self.read_dashboard(&fp, 0);
        if !data.errors.is_empty() {
            return Err(invalid(data.errors.join("; ")));
        }
        Ok(data
            .latest
            .get(&normalize_file_id(id).map_err(invalid)?)
            .cloned())
    }
    // Retained for existing state/collector integrations; GUI reads external logs only.
    pub fn publish(&self, r: &FileScanRecord) -> io::Result<()> {
        self.publish_stage("jev", r)
    }
    fn publish_stage(&self, stage: &str, r: &FileScanRecord) -> io::Result<()> {
        let mut r = r.clone();
        r.file_id = normalize_file_id(&r.file_id).map_err(invalid)?;
        let bytes = serde_json::to_vec_pretty(&r).map_err(invalid)?;
        let dir = self.root.join(stage);
        fs::create_dir_all(dir.join("latest"))?;
        fs::create_dir_all(dir.join("history"))?;
        use std::hash::{Hash, Hasher};
        let mut hash = std::collections::hash_map::DefaultHasher::new();
        r.run_id.hash(&mut hash);
        let history = dir.join("history").join(format!(
            "{}-{}-{:x}.json",
            r.file_id,
            r.processed_at.timestamp_micros(),
            hash.finish()
        ));
        fs::write(history, &bytes)?;
        let latest = dir.join("latest").join(format!("{}.json", r.file_id));
        let old = fs::read(&latest)
            .ok()
            .and_then(|b| serde_json::from_slice::<FileScanRecord>(&b).ok());
        if old.is_none_or(|old| {
            (r.scan_started_at, r.processed_at) >= (old.scan_started_at, old.processed_at)
        }) {
            let temp = latest.with_extension("tmp");
            fs::write(&temp, bytes)?;
            fs::rename(temp, latest)?;
        }
        Ok(())
    }
    pub fn recover_corrupt_latest(&self, fp: &ScanStoreFingerprint) -> Recovery {
        let mut out = Recovery::default();
        for (path, bytes) in &fp.0 {
            if !path.parent().is_some_and(|p| p.ends_with("latest"))
                || serde_json::from_slice::<FileScanRecord>(bytes).is_ok()
            {
                continue;
            }
            let stage = if path.starts_with(self.root.join("jev")) {
                "jev"
            } else {
                "regex"
            };
            let id = path.file_stem().and_then(|s| s.to_str()).unwrap_or("");
            let replacement =
                fp.0.iter()
                    .filter(|(p, _)| p.starts_with(self.root.join(stage).join("history")))
                    .flat_map(|(path, bytes)| {
                        if path.extension().is_some_and(|ext| ext == "jsonl") {
                            bytes.split(|b| *b == b'\n').collect::<Vec<_>>()
                        } else {
                            vec![bytes.as_slice()]
                        }
                    })
                    .filter_map(|b| serde_json::from_slice::<FileScanRecord>(b).ok())
                    .filter(|r| r.file_id == id)
                    .max_by_key(|r| r.processed_at);
            if let Some(r) = replacement {
                let backup = self
                    .root
                    .join("recovery")
                    .join(stage)
                    .join(format!("{id}-{}.json", Utc::now().timestamp_micros()));
                let result = (|| -> io::Result<()> {
                    fs::create_dir_all(backup.parent().unwrap())?;
                    fs::write(&backup, bytes)?;
                    fs::write(path, serde_json::to_vec_pretty(&r).map_err(invalid)?)?;
                    Ok(())
                })();
                match result {
                    Ok(()) => {
                        out.repaired += 1;
                        out.warnings.push(format!(
                            "{stage}/latest/{id}.json 복원 · recovery/{stage}/{}",
                            backup.file_name().unwrap().to_string_lossy()
                        ));
                    }
                    Err(e) => out.errors.push(e.to_string()),
                }
            }
        }
        out
    }
}
