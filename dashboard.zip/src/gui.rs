//Windows 창에서 대시보드를 표시하고 수집 작업의 종료를 관리.

use crate::controller::DashboardController;
use crate::view::DashboardView;
use crate::{BackgroundTask, DashboardState};
use eframe::egui;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Condvar, Mutex, MutexGuard};
use std::time::Duration;
use windows::core::{w, PCWSTR};
use windows::Win32::UI::WindowsAndMessaging::{
    MessageBoxW, MB_ICONERROR, MB_ICONINFORMATION, MB_OK,
};

#[derive(Default)]
struct TaskControl {
    state: Mutex<TaskState>,
    completed: Condvar,
    closing: AtomicBool,
    stopping: AtomicBool,
    joined: AtomicBool,
}

#[derive(Default)]
struct TaskState {
    task: Option<Box<dyn BackgroundTask>>,
    joining: bool,
    result: Option<Result<(), String>>,
}

impl TaskControl {
    fn lock(&self) -> MutexGuard<'_, TaskState> {
        self.state.lock().unwrap_or_else(|error| error.into_inner())
    }

    fn request_stop(&self) {
        if let Some(task) = self.lock().task.as_ref() {
            if !task.is_finished() {
                self.stopping.store(true, Ordering::Release);
                task.request_stop();
            }
        }
    }

    fn join(&self) -> Result<(), String> {
        let mut state = self.lock();
        while state.joining && state.result.is_none() {
            state = self
                .completed
                .wait(state)
                .unwrap_or_else(|error| error.into_inner());
        }
        if let Some(result) = &state.result {
            return result.clone();
        }
        state.joining = true;
        let task = state.task.take();
        drop(state);
        let result = catch_unwind(AssertUnwindSafe(|| {
            task.map_or(Ok(()), |task| {
                task.request_stop();
                task.join()
            })
        }))
        .unwrap_or_else(|_| Err("앱 수집 작업을 종료하는 중 panic이 발생했습니다.".into()));
        self.lock().result = Some(result.clone());
        self.joined.store(true, Ordering::Release);
        self.completed.notify_all();
        result
    }

    fn close(self: &Arc<Self>, state: &DashboardState, context: &egui::Context) {
        if self.closing.swap(true, Ordering::AcqRel) {
            return;
        }
        self.stopping.store(true, Ordering::Release);
        let control = Arc::clone(self);
        let worker_state = state.clone();
        let worker_context = context.clone();
        let worker = std::thread::Builder::new()
            .name("secretwatch-shutdown".into())
            .spawn(move || {
                control.request_stop();
                if let Err(error) = control.join() {
                    worker_state.set_status("error", Some(error));
                }
                worker_context.request_repaint();
            });
        if let Err(error) = worker {
            self.request_stop();
            self.closing.store(false, Ordering::Release);
            state.set_status(
                "error",
                Some(format!(
                    "종료 작업을 시작하지 못했습니다. 중지를 요청했으며 창 닫기를 다시 시도할 수 있습니다. {error}"
                )),
            );
            context.request_repaint();
        }
    }
}

struct Desktop {
    dashboard: DashboardState,
    task: Arc<TaskControl>,
    data: DashboardController,
    view: DashboardView,
}

impl eframe::App for Desktop {
    fn update(&mut self, context: &egui::Context, _frame: &mut eframe::Frame) {
        if context.input(|input| input.viewport().close_requested())
            && !self.task.joined.load(Ordering::Acquire)
        {
            context.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.task.close(&self.dashboard, context);
        }
        if self.task.closing.load(Ordering::Acquire) && self.task.joined.load(Ordering::Acquire) {
            context.send_viewport_cmd(egui::ViewportCommand::Close);
        }
        self.data.poll();
        if self.task.stopping.load(Ordering::Acquire)
            && (self.data.model.health.is_null()
                || matches!(
                    self.data.model.health["status"].as_str(),
                    Some("starting" | "collecting" | "scanning" | "watching")
                ))
        {
            self.data.model.health["status"] = "stopping".into();
        }
        let response = self.view.show(context, &self.data.model);
        for action in response.actions {
            self.data.dispatch(action);
        }
        if response.stop_requested {
            self.task.request_stop();
            context.request_repaint();
        }
        if self.task.closing.load(Ordering::Acquire) {
            context.request_repaint_after(Duration::from_millis(100));
        }
    }
}

impl Drop for Desktop {
    fn drop(&mut self) {
        self.task.request_stop();
        let _ = self.task.join();
    }
}

pub(crate) fn configure_fonts(context: &egui::Context) {
    let windows_directory = std::env::var_os("WINDIR")
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| "C:\\Windows".into());
    let fonts_directory = windows_directory.join("Fonts");
    let mut fonts = egui::FontDefinitions::default();
    for name in ["malgun.ttf", "gulim.ttc", "segoeui.ttf"] {
        let Ok(bytes) = std::fs::read(fonts_directory.join(name)) else {
            continue;
        };
        fonts
            .font_data
            .insert(name.into(), Arc::new(egui::FontData::from_owned(bytes)));
        for family in [egui::FontFamily::Proportional, egui::FontFamily::Monospace] {
            fonts
                .families
                .entry(family)
                .or_default()
                .insert(0, name.into());
        }

        if name != "segoeui.ttf" {
            break;
        }
    }
    context.set_fonts(fonts);
}

pub fn run(
    state: DashboardState,
    start: impl FnOnce(DashboardState) -> Result<Box<dyn BackgroundTask>, String>,
) -> Result<(), String> {
    let actions_dir = std::env::var_os("SECRETWATCH_DASHBOARD_DATA_DIR")
        .map(std::path::PathBuf::from)
        .or_else(|| {
            std::env::var_os("LOCALAPPDATA")
                .map(|p| std::path::PathBuf::from(p).join("SecretWatch/dashboard"))
        })
        .ok_or("로컬 조치 상태 저장 경로를 찾을 수 없습니다.")?;
    state.load_local_actions(actions_dir.join("local-actions.json"))?;
    let control = Arc::new(TaskControl::default());
    let task = Arc::clone(&control);
    let mut viewport = egui::ViewportBuilder::default()
        .with_title("SecretWatch")
        .with_inner_size([1440.0, 940.0])
        .with_min_inner_size([1050.0, 700.0]);
    if let Ok(icon) = eframe::icon_data::from_png_bytes(include_bytes!("../icons/icon.png")) {
        viewport = viewport.with_icon(Arc::new(icon));
    }
    let options = eframe::NativeOptions {
        viewport,
        renderer: eframe::Renderer::Glow,
        ..Default::default()
    };
    let result = eframe::run_native(
        "SecretWatch",
        options,
        Box::new(move |creation| {
            configure_fonts(&creation.egui_ctx);
            DashboardView::configure(&creation.egui_ctx);
            let context = creation.egui_ctx.clone();
            let data = DashboardController::new(state.clone(), move || context.request_repaint())?;
            match start(state.clone()) {
                Ok(background) => task.lock().task = Some(background),
                Err(error) => state.set_status("error", Some(error)),
            }
            Ok(Box::new(Desktop {
                dashboard: state,
                task,
                data,
                view: DashboardView::new(),
            }))
        }),
    );
    let drained = control.join();
    result.map_err(|error| format!("SecretWatch 창 실행 실패: {error}"))?;
    drained
}

pub fn message(text: &str, error: bool) {
    let text: Vec<_> = text.encode_utf16().chain(Some(0)).collect();
    unsafe {
        MessageBoxW(
            None,
            PCWSTR(text.as_ptr()),
            w!("SecretWatch"),
            MB_OK
                | if error {
                    MB_ICONERROR
                } else {
                    MB_ICONINFORMATION
                },
        );
    }
}
