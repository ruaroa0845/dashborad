use eframe::egui::{self, Color32, FontId, Frame, Margin, RichText, Stroke, TextStyle, Ui};

pub const SIDEBAR: Color32 = Color32::from_rgb(16, 44, 53);
pub const ACCENT: Color32 = Color32::from_rgb(11, 139, 128);
pub const BACKGROUND: Color32 = Color32::from_rgb(243, 246, 250);
pub const INK: Color32 = Color32::from_rgb(25, 48, 64);
pub const MUTED: Color32 = Color32::from_rgb(113, 131, 153);
pub const LINE: Color32 = Color32::from_rgb(228, 234, 240);
pub const SOFT: Color32 = Color32::from_rgb(245, 249, 251);
pub const SELECTED: Color32 = Color32::from_rgb(234, 243, 242);
pub const RED: Color32 = Color32::from_rgb(199, 61, 73);
pub const AMBER: Color32 = Color32::from_rgb(173, 118, 40);

pub fn configure(context: &egui::Context) {
    let mut style = (*context.style()).clone();
    style.visuals = egui::Visuals::light();
    style.visuals.override_text_color = Some(INK);
    style.visuals.panel_fill = BACKGROUND;
    style.visuals.window_fill = Color32::WHITE;
    style.visuals.window_stroke = Stroke::new(1.0_f32, LINE);
    style.visuals.window_corner_radius = egui::CornerRadius::same(14);
    style.visuals.selection.bg_fill = SELECTED;
    style.visuals.selection.stroke = Stroke::new(1.0_f32, ACCENT);
    style.visuals.hyperlink_color = ACCENT;
    for widget in [
        &mut style.visuals.widgets.inactive,
        &mut style.visuals.widgets.hovered,
        &mut style.visuals.widgets.active,
    ] {
        widget.corner_radius = egui::CornerRadius::same(6);
        widget.fg_stroke = Stroke::new(1.0_f32, INK);
        widget.bg_stroke = Stroke::new(1.0_f32, LINE);
        widget.bg_fill = Color32::WHITE;
        widget.weak_bg_fill = Color32::WHITE;
    }
    style.visuals.widgets.hovered.bg_fill = SOFT;
    style.visuals.widgets.hovered.weak_bg_fill = SOFT;
    style.visuals.widgets.hovered.bg_stroke = Stroke::new(1.0_f32, ACCENT);
    style.visuals.widgets.active.bg_fill = SELECTED;
    style.visuals.widgets.noninteractive.bg_stroke = Stroke::new(1.0_f32, LINE);
    style.spacing.item_spacing = egui::vec2(8.0, 8.0);
    style.spacing.button_padding = egui::vec2(14.0, 9.0);
    style
        .text_styles
        .insert(TextStyle::Body, FontId::proportional(14.0));
    style
        .text_styles
        .insert(TextStyle::Button, FontId::proportional(12.0));
    style
        .text_styles
        .insert(TextStyle::Small, FontId::proportional(11.0));
    style
        .text_styles
        .insert(TextStyle::Heading, FontId::proportional(28.0));
    style
        .text_styles
        .insert(TextStyle::Monospace, FontId::monospace(12.0));
    context.set_style(style);
}

pub fn card() -> Frame {
    Frame::new()
        .fill(Color32::WHITE)
        .corner_radius(12)
        .stroke(Stroke::new(1.0_f32, Color32::from_rgb(237, 241, 245)))
        .inner_margin(Margin::same(24))
}

pub fn text(value: impl Into<String>, size: f32, color: Color32) -> RichText {
    RichText::new(value).size(size).color(color)
}

pub fn muted(ui: &mut Ui, value: impl Into<String>) {
    ui.label(text(value, 11.0, MUTED));
}

pub fn heading(ui: &mut Ui, value: impl Into<String>) {
    ui.label(text(value, 16.0, INK).strong());
}

pub fn badge(ui: &mut Ui, severity: &str) {
    let (foreground, background) = match severity {
        "high" => (RED, Color32::from_rgb(252, 236, 239)),
        "medium" => (AMBER, Color32::from_rgb(255, 244, 228)),
        "low" => (
            Color32::from_rgb(84, 116, 161),
            Color32::from_rgb(237, 242, 250),
        ),
        _ => {
            muted(ui, "—");
            return;
        }
    };
    let label = ui.painter().layout_no_wrap(
        severity.to_uppercase(),
        FontId::proportional(10.0),
        foreground,
    );
    let (rect, _) =
        ui.allocate_exact_size(label.size() + egui::vec2(14.0, 8.0), egui::Sense::hover());
    ui.painter().rect_filled(rect, 4, background);
    ui.painter()
        .galley(rect.min + egui::vec2(7.0, 4.0), label, foreground);
}

pub fn chip(ui: &mut Ui, value: impl Into<String>, color: Color32) {
    Frame::new()
        .fill(SOFT)
        .corner_radius(4)
        .inner_margin(Margin::symmetric(9, 5))
        .show(ui, |ui| {
            ui.label(text(value, 10.0, color));
        });
}

pub fn scan_label(ui: &mut Ui, status: &str) {
    let color = match status {
        "completed" => ACCENT,
        "failed" | "partial" => RED,
        "scanning" | "pending" | "awaiting_jev" | "needs_review" => AMBER,
        _ => MUTED,
    };
    ui.label(text(scan_name(status), 12.0, color));
}

pub fn scan_name(status: &str) -> &str {
    match status {
        "completed" => "검사 완료",
        "needs_review" => "검토 필요",
        "failed" => "검사 실패",
        "partial" => "부분 검사",
        "scanning" => "검사 중",
        "pending" => "검사 대기",
        "awaiting_jev" => "검사 중",
        "not_scanned" => "검사 결과 없음",
        "not_applicable" => "검사 대상 아님",
        "excluded" => "검사 제외",
        "skipped" => "검사 생략",
        "unsupported" => "미지원",
        other => other,
    }
}

pub fn reason_text(message: &str) -> &str {
    for code in
        message.split(|character: char| !character.is_ascii_alphanumeric() && character != '_')
    {
        let description = match code {
            "JEV_SETUP_NOT_FOUND" => {
                "JEV 설치 설정을 찾을 수 없습니다. Setup을 설치한 뒤 다시 실행해 주세요."
            }
            "BUNDLED_RUNTIME_MISSING" => {
                "설치된 JEV 실행 파일을 찾을 수 없습니다. Setup을 다시 설치해 주세요."
            }
            "BUNDLED_DECISION_MODEL_MISSING" => {
                "설치된 판별 모델을 찾을 수 없습니다. Setup을 다시 설치해 주세요."
            }
            "MODEL_NOT_FOUND" => {
                "설정된 판별 모델을 찾을 수 없습니다. 설치 설정과 모델 이름을 확인해 주세요."
            }
            "OLLAYA_NOT_RUNNING" => {
                "JEV 판별 서버가 실행되지 않았습니다. 자동 시작 설정을 확인해 주세요."
            }
            "OLLAYA_NOT_READY" | "RUNTIME_NOT_READY" => {
                "JEV 판별 서버가 준비되지 않았습니다. 서버 상태를 확인해 주세요."
            }
            "OLLAYA_STARTUP_FAILED" | "OLLAYA_STARTUP_EXITED" => {
                "JEV 판별 서버를 시작하지 못했습니다. 설치 상태와 서버 로그를 확인해 주세요."
            }
            "OLLAYA_STARTUP_TIMEOUT" => {
                "JEV 판별 서버의 준비 시간이 초과되었습니다. 서버 상태를 확인해 주세요."
            }
            "CONNECTION_REFUSED" => "로컬 판별 서버에 연결하지 못했습니다.",
            "REQUEST_TIMEOUT" => "판별 요청 시간이 초과되었습니다.",
            _ => continue,
        };
        return description;
    }
    message
}

pub fn decision_name(status: &str) -> &str {
    match status {
        "classified" => "판별 완료",
        "needs_review" => "검토 필요",
        "excluded" => "판별 제외",
        "failed" => "판별 실패",
        "processing" => "판별 중",
        "awaiting_jev" => "검사 중",
        "unclassified" | "" => "판별 대기",
        other => other,
    }
}

pub fn reality_name(reality: &str) -> &str {
    match reality {
        "likely_real" => "실사용 추정",
        "likely_test" => "테스트용 추정",
        "placeholder" => "입력 예시 추정",
        "" => "미판별",
        other => other,
    }
}

pub fn secret_type_name(kind: &str) -> &str {
    match kind {
        "api_key" => "API 키",
        "access_token" => "접근 토큰",
        "ssh_key" => "SSH 키",
        "x509_certificate" => "X.509 인증서",
        "connection_string" => "연결 문자열",
        "db_password" => "DB 비밀번호",
        "other_secret_key" => "기타 비밀 키",
        "resident_registration_number" => "주민등록번호",
        "phone_number" => "전화번호",
        "email_address" => "이메일",
        "bank_account" => "계좌번호",
        "password" => "비밀번호",
        "des" => "DES",
        "rc4" => "RC4",
        "md5" => "MD5",
        "sha1" => "SHA-1",
        "ecb" => "ECB",
        "unclassified" => "유형 미분류",
        "" => "유형 미판별",
        other => other,
    }
}

pub fn absent_risk_name(finding: &serde_json::Value) -> &'static str {
    if value(finding, "status") == "excluded" {
        "판별 제외"
    } else if value(finding, "status") == "classified"
        && matches!(
            value(finding, "secret_reality"),
            "likely_test" | "placeholder"
        )
    {
        "위험도 평가 대상 아님"
    } else {
        "위험도 미판정"
    }
}

pub fn category_name(category: &str) -> &str {
    match category {
        "secret" => "Secret",
        "pii" => "개인정보",
        "weak_crypto" => "취약 암호화",
        "environment" => "로그·환경 파일",
        other => other,
    }
}

pub fn number(value: u64) -> String {
    let digits = value.to_string();
    let mut output = String::with_capacity(digits.len() + digits.len() / 3);
    for (index, digit) in digits.chars().enumerate() {
        if index > 0 && (digits.len() - index).is_multiple_of(3) {
            output.push(',');
        }
        output.push(digit);
    }
    output
}

pub fn value<'a>(object: &'a serde_json::Value, key: &str) -> &'a str {
    object[key].as_str().unwrap_or("")
}

pub fn date(value: &serde_json::Value) -> String {
    local_date(value).unwrap_or_else(|| value.as_str().unwrap_or("—").to_owned())
}

#[cfg(windows)]
fn local_date(value: &serde_json::Value) -> Option<String> {
    use windows::Win32::Foundation::{FILETIME, SYSTEMTIME};
    use windows::Win32::System::Time::{
        FileTimeToSystemTime, SystemTimeToFileTime, SystemTimeToTzSpecificLocalTime,
    };
    let ticks = if let Some(milliseconds) = value.as_i64() {
        u64::try_from((i128::from(milliseconds) + 11_644_473_600_000) * 10_000).ok()?
    } else {
        let iso = value.as_str()?;
        let part = |start, end| iso.get(start..end)?.parse::<u16>().ok();
        let mut utc = SYSTEMTIME {
            wYear: part(0, 4)?,
            wMonth: part(5, 7)?,
            wDay: part(8, 10)?,
            wHour: part(11, 13)?,
            wMinute: part(14, 16)?,
            wSecond: part(17, 19)?,
            ..Default::default()
        };
        let mut zone = iso.get(19..)?;
        if let Some(fraction) = zone.strip_prefix('.') {
            let length = fraction.bytes().take_while(u8::is_ascii_digit).count();
            let milliseconds = format!(
                "{:0<3}",
                fraction[..length].chars().take(3).collect::<String>()
            );
            utc.wMilliseconds = milliseconds.parse().ok()?;
            zone = &fraction[length..];
        }
        let offset_minutes: i64 = if zone == "Z" {
            0
        } else {
            let sign = match zone.as_bytes().first()? {
                b'+' => 1,
                b'-' => -1,
                _ => return None,
            };
            let hour = zone.get(1..3)?.parse::<i64>().ok()?;
            let minute = zone.get(4..6)?.parse::<i64>().ok()?;
            if hour > 23 || minute > 59 || zone.get(3..4)? != ":" {
                return None;
            }
            sign * (hour * 60 + minute)
        };
        let mut file_time = FILETIME::default();
        unsafe {
            SystemTimeToFileTime(&utc, &mut file_time).ok()?;
        }
        let ticks =
            (u64::from(file_time.dwHighDateTime) << 32) | u64::from(file_time.dwLowDateTime);
        u64::try_from(i128::from(ticks) - i128::from(offset_minutes) * 600_000_000).ok()?
    };
    let file_time = FILETIME {
        dwLowDateTime: ticks as u32,
        dwHighDateTime: (ticks >> 32) as u32,
    };
    let mut utc = SYSTEMTIME::default();
    let mut local = SYSTEMTIME::default();
    unsafe {
        FileTimeToSystemTime(&file_time, &mut utc).ok()?;
        SystemTimeToTzSpecificLocalTime(None, &utc, &mut local).ok()?;
    }
    Some(format!(
        "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
        local.wYear, local.wMonth, local.wDay, local.wHour, local.wMinute, local.wSecond
    ))
}

#[cfg(not(windows))]
fn local_date(_value: &serde_json::Value) -> Option<String> {
    None
}

pub fn visible_reason(message: &str) -> String {
    message
        .split(['\n', '·'])
        .map(str::trim)
        .filter(|part| {
            let normalized: String = part
                .chars()
                .filter(|c| !c.is_whitespace() && !matches!(c, '_' | '-'))
                .flat_map(char::to_lowercase)
                .collect();
            ![
                "timeout",
                "timedout",
                "deadlineexceeded",
                "시간초과",
                "시간이초과",
                "타임아웃",
            ]
            .iter()
            .any(|word| normalized.contains(word))
        })
        .collect::<Vec<_>>()
        .join(" · ")
}

pub fn action_name(status: &str) -> &str {
    match status {
        "open" => "미조치",
        "in_progress" => "검토 중",
        "resolved" => "해결됨",
        "false_positive" => "오탐",
        other => other,
    }
}
