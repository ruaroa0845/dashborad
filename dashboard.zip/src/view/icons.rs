use eframe::egui::{self, Color32, Painter, Rect, Sense, Shape, Stroke, Ui};

#[derive(Clone, Copy)]
pub enum Icon {
    Logo,
    Overview,
    Folder,
    File,
    Clock,
    Search,
}

pub fn show(ui: &mut Ui, icon: Icon, size: f32, color: Color32) {
    let (rect, _) = ui.allocate_exact_size(egui::vec2(size, size), Sense::hover());
    paint(ui.painter(), rect, icon, color);
}

pub fn paint(painter: &Painter, rect: Rect, icon: Icon, color: Color32) {
    let point = |x: f32, y: f32| rect.min + egui::vec2(x * rect.width(), y * rect.height());
    let stroke = Stroke::new(1.4_f32, color);
    let line = |a: (f32, f32), b: (f32, f32)| {
        painter.line_segment([point(a.0, a.1), point(b.0, b.1)], stroke);
    };
    let outline = |vertices: &[(f32, f32)]| {
        painter.add(Shape::closed_line(
            vertices.iter().map(|(x, y)| point(*x, *y)).collect(),
            stroke,
        ));
    };
    match icon {
        Icon::Logo => {
            outline(&[
                (0.5, 0.05),
                (0.89, 0.275),
                (0.89, 0.725),
                (0.5, 0.95),
                (0.11, 0.725),
                (0.11, 0.275),
            ]);
        }
        Icon::Overview => {
            for (x, y) in [(0.12, 0.12), (0.57, 0.12), (0.12, 0.57), (0.57, 0.57)] {
                painter.rect_stroke(
                    Rect::from_min_max(point(x, y), point(x + 0.3, y + 0.3)),
                    1,
                    stroke,
                    egui::StrokeKind::Inside,
                );
            }
        }
        Icon::Folder => outline(&[
            (0.08, 0.2),
            (0.42, 0.2),
            (0.53, 0.33),
            (0.92, 0.33),
            (0.92, 0.82),
            (0.08, 0.82),
        ]),
        Icon::File => {
            outline(&[
                (0.2, 0.08),
                (0.65, 0.08),
                (0.83, 0.27),
                (0.83, 0.92),
                (0.2, 0.92),
            ]);
            line((0.62, 0.08), (0.62, 0.3));
            line((0.62, 0.3), (0.83, 0.3));
            line((0.33, 0.48), (0.67, 0.48));
            line((0.33, 0.65), (0.67, 0.65));
        }
        Icon::Clock => {
            painter.circle_stroke(rect.center(), rect.width() * 0.4, stroke);
            line((0.5, 0.25), (0.5, 0.52));
            line((0.5, 0.52), (0.7, 0.62));
        }
        Icon::Search => {
            painter.circle_stroke(point(0.4, 0.4), rect.width() * 0.28, stroke);
            line((0.61, 0.61), (0.91, 0.91));
        }
    }
}
