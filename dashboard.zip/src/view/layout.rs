use super::*;

impl DashboardView {
    pub(super) fn sidebar(
        &self,
        context: &egui::Context,
        model: &UiModel,
        output: &mut ViewActions,
    ) {
        let compact = context.content_rect().width() <= 1150.0;
        egui::SidePanel::left("workspace-sidebar")
            .exact_width(if compact { 200.0 } else { 224.0 })
            .resizable(false)
            .frame(Frame::new().fill(SIDEBAR).inner_margin(if compact {
                Margin::symmetric(14, 27)
            } else {
                Margin::symmetric(20, 32)
            }))
            .show(context, |ui| {
                ui.visuals_mut().widgets.noninteractive.bg_stroke =
                    Stroke::new(1.0_f32, Color32::from_rgb(43, 69, 77));
                ui.horizontal(|ui| {
                    icons::show(ui, icons::Icon::Logo, 23.0, Color32::WHITE);
                    ui.label(
                        text(
                            "SecretWatch",
                            if compact { 19.0 } else { 20.0 },
                            Color32::WHITE,
                        )
                        .strong(),
                    );
                });
                ui.add_space(28.0);
                ui.separator();
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    Frame::new()
                        .fill(Color32::from_rgb(40, 71, 80))
                        .corner_radius(7)
                        .inner_margin(Margin::symmetric(11, 8))
                        .show(ui, |ui| {
                            ui.label(text("S", 14.0, Color32::WHITE).strong());
                        });
                    ui.vertical(|ui| {
                        ui.label(
                            text("로컬 워크스페이스", 11.0, Color32::from_rgb(229, 238, 240))
                                .strong(),
                        );
                        ui.label(text(
                            "개발 환경 보안 모니터링",
                            10.0,
                            Color32::from_rgb(141, 167, 175),
                        ));
                    });
                });
                ui.add_space(16.0);
                ui.separator();
                ui.add_space(23.0);
                ui.label(text("WORKSPACE", 9.0, Color32::from_rgb(101, 133, 143)));
                ui.add_space(10.0);
                for (view, icon, name) in [
                    (View::Overview, icons::Icon::Overview, "위험 대시보드"),
                    (View::Files, icons::Icon::Folder, "통합 경로 목록"),
                    (View::Scans, icons::Icon::Clock, "검사 이력"),
                    (View::Criteria, icons::Icon::File, "위험도 기준표"),
                ] {
                    let selected = model.view == view;
                    let foreground = if selected {
                        Color32::WHITE
                    } else {
                        Color32::from_rgb(183, 201, 206)
                    };
                    let (rect, response) = ui.allocate_exact_size(
                        egui::vec2(ui.available_width(), 49.0),
                        Sense::click(),
                    );
                    ui.painter().rect_filled(
                        rect,
                        7,
                        if selected {
                            ACCENT
                        } else if response.hovered() {
                            Color32::from_rgb(29, 62, 70)
                        } else {
                            SIDEBAR
                        },
                    );
                    icons::paint(
                        ui.painter(),
                        egui::Rect::from_center_size(
                            egui::pos2(response.rect.left() + 25.0, response.rect.center().y),
                            egui::vec2(15.0, 15.0),
                        ),
                        icon,
                        foreground,
                    );
                    ui.painter().text(
                        egui::pos2(rect.left() + 45.0, rect.center().y),
                        egui::Align2::LEFT_CENTER,
                        name,
                        egui::FontId::proportional(13.0),
                        foreground,
                    );
                    if response.clicked() {
                        output.actions.push(Action::SetView(view));
                    }
                    ui.add_space(5.0);
                }
                ui.with_layout(Layout::bottom_up(Align::Min), |ui| {
                    ui.label(text(
                        "SecretWatch                       v0.1.0",
                        10.0,
                        Color32::from_rgb(139, 163, 171),
                    ));
                    ui.separator();
                    ui.add_space(14.0);
                    ui.label(text(
                        "민감정보는 마스킹하여 표시합니다.",
                        10.0,
                        Color32::from_rgb(127, 156, 165),
                    ));
                    ui.add_space(8.0);
                    ui.label(text(
                        "● LOCAL WORKSPACE",
                        9.0,
                        Color32::from_rgb(118, 199, 186),
                    ));
                });
            });
    }

    pub(super) fn topbar(
        &self,
        context: &egui::Context,
        model: &UiModel,
        output: &mut ViewActions,
    ) {
        let compact = context.content_rect().width() <= 1150.0;
        egui::TopBottomPanel::top("status-topbar")
            .exact_height(96.0)
            .frame(
                Frame::new()
                    .fill(Color32::from_rgb(248, 250, 252))
                    .inner_margin(Margin::symmetric(if compact { 24 } else { 32 }, 12)),
            )
            .show(context, |ui| {
                ui.allocate_ui_with_layout(
                    egui::vec2(ui.available_width(), 72.0),
                    Layout::left_to_right(Align::Center),
                    |ui| {
                        let status = value(&model.health, "status");
                        let name = match status {
                            "idle" => "감시 준비",
                            "scanning" => "초기 검사 중",
                            "starting" => "감시 시작 중",
                            "collecting" => "파일 목록 수집 중",
                            "watching" => "실시간 감시 중",
                            "stopping" => "감시 중지 중",
                            "stopped" => "감시 중지됨",
                            "failed" | "error" => "감시 오류",
                            _ => "연결 중…",
                        };
                        ui.label(text("●", 10.0, ACCENT));
                        ui.label(text(format!("엔진 · JEV | {status}"), 11.0, ACCENT))
                            .on_hover_text(format!("{name}\n{}", value(&model.health, "message")));
                        ui.add_space(12.0);
                        ui.separator();
                        ui.allocate_ui_with_layout(
                            egui::vec2(if compact { 270.0 } else { 360.0 }, 68.0),
                            Layout::top_down(Align::Min),
                            |ui| progress::show(ui, model),
                        );
                        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                            let enabled = matches!(
                                status,
                                "starting" | "collecting" | "scanning" | "watching"
                            );
                            let label = if status == "stopping" {
                                "중지 중…"
                            } else {
                                "감시 중지"
                            };
                            if ui.add_enabled(enabled, egui::Button::new(label)).clicked() {
                                output.stop_requested = true;
                            }
                            if ui
                                .add_enabled(
                                    !model.loading,
                                    egui::Button::new(text("↻", 22.0, MUTED)).frame(false),
                                )
                                .on_hover_text("지금 새로고침")
                                .clicked()
                            {
                                output.actions.push(Action::Refresh);
                            }
                            if let Some(time) = model.last_refresh_ms.filter(|_| !compact) {
                                ui.vertical(|ui| {
                                    muted(ui, format!("화면 조회 {}", date(&Value::from(time))));
                                    muted(
                                        ui,
                                        format!(
                                            "결과 수신 {}",
                                            date(&model.health["result_received_at"])
                                        ),
                                    );
                                });
                            }
                        });
                    },
                );
            });
    }
}
