use super::theme::*;
use eframe::egui::{self, Align, Layout, Margin, Ui};

const SUMMARY: &[(&str, &str)] = &[
    ("api key", "high"),
    ("X.509 인증서", "high"),
    ("DB Password", "high"),
    ("ssh key", "high"),
    ("etc key. (ex. SECRET_TOKEN)", "high"),
    ("회원 주민등록번호", "high"),
    ("회원 비밀번호", "high"),
    ("Connection String", "medium"),
    ("access token", "medium"),
    ("회원 계좌번호", "medium"),
    ("DES 알고리즘 사용", "medium"),
    ("RC4 알고리즘 사용", "medium"),
    ("MD5 알고리즘 사용", "medium"),
    ("SHA-1", "medium"),
    ("ECB 모드", "medium"),
    ("회원 이메일", "low"),
    ("회원 전화번호", "low"),
];

pub fn show(ui: &mut Ui, expanded: &mut [bool; 4]) {
    let width = ui.available_width().min(1050.0);
    ui.allocate_ui_with_layout(egui::vec2(width, 0.0), Layout::top_down(Align::Min), |ui| {
        ui.set_width(width);
        contents(ui, expanded);
    });
}

fn contents(ui: &mut Ui, expanded: &mut [bool; 4]) {
    card().show(ui, |ui| {
        ui.set_width(ui.available_width());
        heading(ui, "탐지 유효성 기준");
        ui.add_space(20.0);
        let width = ui.available_width().max(860.0);
        egui::ScrollArea::horizontal()
            .id_salt("validity-policy")
            .show(ui, |ui| {
                ui.set_width(width);
                ui.spacing_mut().item_spacing.x = 0.0;
                ui.horizontal(|ui| {
                    left_cell(ui, width * 0.45, 24.0, |ui| muted(ui, "분류"));
                    centered_cell(ui, width * 0.55, 24.0, |ui| muted(ui, "의미"));
                });
                for (code, label, meaning) in [
                    (
                        "likely_real",
                        "실사용 추정",
                        "실제로 사용하는 API 키·인증정보 등으로 보이는 값",
                    ),
                    (
                        "likely_test",
                        "테스트용 추정",
                        "개발·테스트 목적으로 사용되는 것으로 보이는 값",
                    ),
                    (
                        "placeholder",
                        "입력 예시 추정",
                        "YOUR_API_KEY처럼 실제 값을 넣기 전에 표시되는 값",
                    ),
                ] {
                    ui.horizontal_top(|ui| {
                        left_cell(ui, width * 0.45, 48.0, |ui| {
                            ui.label(text(code, 12.0, INK).monospace());
                            muted(ui, label);
                        });
                        centered_cell(ui, width * 0.55, 48.0, |ui| {
                            ui.add(egui::Label::new(text(meaning, 13.0, INK)).extend());
                        });
                    });
                    ui.add_space(8.0);
                }
            });
    });
    ui.add_space(20.0);
    card().show(ui, |ui| {
        ui.set_width(ui.available_width());
        heading(ui, "종합 위험도 기준");
        muted(ui, "실사용 추정으로 판별된 유형에 적용합니다. 테스트용·입력 예시·미판정은 Low로 분류하지 않습니다.");
        ui.add_space(20.0);
        policy_table(ui, SUMMARY);
    });
    ui.add_space(20.0);
    card().show(ui, |ui| {
        ui.set_width(ui.available_width());
        heading(ui, "카테고리별 위험도 기준");
        let categories: [(&str, &[usize]); 4] = [
            ("인증 및 비밀정보", &[0, 1, 2, 3, 4, 7, 8]),
            ("개인정보", &[5, 6, 9, 15, 16]),
            ("취약한 암호화 알고리즘", &[10, 11, 12, 13, 14]),
            ("비구조화 로그 & 환경 파일", &[]),
        ];
        for (index, (name, indices)) in categories.into_iter().enumerate() {
            ui.add_space(16.0);
            let count = indices.len();
            let symbol = if expanded[index] { "−" } else { "+" };
            let response = ui.add_sized(
                [ui.available_width(), 48.0],
                egui::Button::new(
                    text(format!("{symbol}  {name}     {count}개 항목"), 13.0, INK).strong(),
                )
                .fill(SOFT)
                .corner_radius(8),
            );
            if response.clicked() {
                expanded[index] = !expanded[index];
            }
            if expanded[index] {
                if index == 3 {
                    muted(ui, ".env 자체에 고정 위험도를 부여하지 않습니다. 실제 내용의 JEV 최종 유형으로 판정하며, 검사 제외 여부는 엔진 정책에 따릅니다.");
                    continue;
                }
                let rows: Vec<_> = indices.iter().map(|index| SUMMARY[*index]).collect();
                ui.push_id(index, |ui| policy_table(ui, &rows));
            }
        }
    });
}

fn policy_table(ui: &mut Ui, rows: &[(&str, &str)]) {
    let width = ui.available_width().max(860.0);
    egui::ScrollArea::horizontal()
        .id_salt("policy-table-width")
        .show(ui, |ui| {
            ui.set_width(width);
            ui.spacing_mut().item_spacing.x = 0.0;
            egui::Frame::new()
                .fill(SOFT)
                .inner_margin(Margin::symmetric(0, 12))
                .show(ui, |ui| {
                    ui.set_width(width);
                    ui.horizontal(|ui| {
                        left_cell(ui, width * 0.7, 18.0, |ui| muted(ui, "탐지 항목"));
                        centered_cell(ui, width * 0.3, 18.0, |ui| muted(ui, "위험도"));
                    });
                });
            for (name, severity) in rows {
                ui.horizontal(|ui| {
                    left_cell(ui, width * 0.7, 44.0, |ui| {
                        ui.add_space(10.0);
                        ui.label(text(*name, 13.0, INK));
                    });
                    centered_cell(ui, width * 0.3, 44.0, |ui| {
                        ui.add_space(8.0);
                        badge(ui, severity);
                    });
                });
                ui.separator();
            }
        });
}

fn centered_cell(ui: &mut Ui, width: f32, height: f32, contents: impl FnOnce(&mut Ui)) {
    ui.allocate_ui_with_layout(
        egui::vec2(width, height),
        Layout::top_down(Align::Center),
        |ui| {
            ui.set_width(width);
            ui.set_min_height(height);
            contents(ui);
        },
    );
}

fn left_cell(ui: &mut Ui, width: f32, height: f32, contents: impl FnOnce(&mut Ui)) {
    ui.allocate_ui_with_layout(
        egui::vec2(width, height),
        Layout::top_down(Align::Min),
        |ui| {
            ui.set_width(width);
            ui.set_min_height(height);
            egui::Frame::new()
                .inner_margin(Margin::symmetric(16, 0))
                .show(ui, contents);
        },
    );
}
