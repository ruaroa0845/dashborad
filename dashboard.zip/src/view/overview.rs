use super::*;

pub(super) fn show(
    ui: &mut Ui,
    model: &UiModel,
    output: &mut ViewActions,
    chosen: &mut String,
    detail_file: &mut Option<String>,
) {
    let data = &model.summary;
    let metrics = [
        ("수집 파일", "file_count", "종류가 확인된 파일", INK),
        (
            "수집 폴더",
            "folder_count",
            "폴더 자체는 내용 검사 대상 아님",
            INK,
        ),
        (
            "JEV 확정 위험",
            "active_findings",
            "판별 완료 · 실사용 추정",
            RED,
        ),
        (
            "검사 확인 필요",
            "unscanned_count",
            "미검사 · 진행 · 실패 · 제외 포함",
            ACCENT,
        ),
    ];
    let columns = if ui.available_width() < 900.0 { 2 } else { 4 };
    for row in metrics.chunks(columns) {
        ui.columns(columns, |uis| {
            for (ui, (label, key, note, color)) in uis.iter_mut().zip(row) {
                card().show(ui, |ui| {
                    ui.set_min_width((ui.available_width() - 1.0).max(0.0));
                    ui.label(text(*label, 12.0, MUTED));
                    ui.add_space(12.0);
                    ui.label(text(number(data[*key].as_u64().unwrap_or(0)), 32.0, *color).strong());
                    muted(ui, *note);
                });
            }
        });
        ui.add_space(12.0);
    }
    ui.horizontal_wrapped(|ui| {
        chip(
            ui,
            format!(
                "미조치 위험 {}건",
                number(data["unresolved_findings"].as_u64().unwrap_or(0))
            ),
            RED,
        );
        chip(
            ui,
            format!(
                "검토 필요 {}건",
                number(data["review_required_count"].as_u64().unwrap_or(0))
            ),
            AMBER,
        );
        for (label, key) in [
            ("검사 중 파일", "scanning_file_count"),
            ("판정 대기 후보", "awaiting_jev_count"),
            ("테스트용", "likely_test_count"),
            ("자리표시자", "placeholder_count"),
        ] {
            chip(
                ui,
                format!("{} {}건", label, number(data[key].as_u64().unwrap_or(0))),
                MUTED,
            );
        }
        chip(
            ui,
            format!(
                "위험도 미판정 {}건",
                number(data["unassessed_count"].as_u64().unwrap_or(0))
            ),
            MUTED,
        );
    });
    ui.add_space(8.0);
    ui.columns(2, |uis| {
        card().show(&mut uis[0], |ui| {
            ui.set_width(ui.available_width());
            heading(ui, "위험도별 탐지");
            muted(ui, "JEV 최종 판별 · 실사용 추정 결과");
            bars(ui, &data["severity"], true);
        });
        card().show(&mut uis[1], |ui| {
            ui.set_width(ui.available_width());
            heading(ui, "탐지 유형");
            muted(ui, "실사용 위험 기준 · 검토 필요 결과 제외");
            bars(ui, &data["categories"], false);
        });
    });
    ui.add_space(22.0);
    card().show(ui, |ui| {
        heading(ui, "최근 탐지 후보");
        ui.add_space(12.0);
        let findings = data["recent_findings"]
            .as_array()
            .map(Vec::as_slice)
            .unwrap_or_default();
        if findings.is_empty() {
            empty(ui, "탐지 후보 내역이 없습니다.", "");
        }
        for finding in findings {
            ui.horizontal(|ui| {
                ui.vertical(|ui| {
                    if ui
                        .add(
                            egui::Button::new(text(value(finding, "title"), 13.0, INK).strong())
                                .frame(false),
                        )
                        .clicked()
                    {
                        *chosen = value(finding, "finding_id").to_owned();
                        *detail_file = Some(value(finding, "file_id").to_owned());
                        output
                            .actions
                            .push(Action::SelectFile(value(finding, "file_id").to_owned()));
                    }
                    muted(
                        ui,
                        format!(
                            "{} · {}",
                            category_name(value(finding, "category")),
                            date(&finding["detected_at"])
                        ),
                    );
                });
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    muted(ui, decision_name(value(finding, "status")));
                    if !value(finding, "secret_reality").is_empty() {
                        muted(ui, reality_name(value(finding, "secret_reality")));
                    }
                    if value(finding, "severity").is_empty() {
                        muted(ui, absent_risk_name(finding));
                    } else {
                        badge(ui, value(finding, "severity"));
                    }
                });
            });
            ui.add_space(8.0);
            ui.separator();
            ui.add_space(8.0);
        }
    });
}

fn bars(ui: &mut Ui, data: &Value, severity: bool) {
    let entries = data
        .as_object()
        .map(|object| object.iter().collect::<Vec<_>>())
        .unwrap_or_default();
    let max = entries
        .iter()
        .map(|(_, count)| count.as_u64().unwrap_or(0))
        .max()
        .unwrap_or(1)
        .max(1) as f32;
    for (key, count) in entries {
        let count = count.as_u64().unwrap_or(0);
        ui.add_space(20.0);
        ui.horizontal(|ui| {
            cell(ui, 88.0, 20.0, |ui| {
                ui.label(text(
                    if severity {
                        key.to_uppercase()
                    } else {
                        category_name(key).to_owned()
                    },
                    12.0,
                    INK,
                ));
            });
            let width = (ui.available_width() - 40.0).max(35.0);
            let (rect, _) = ui.allocate_exact_size(egui::vec2(width, 9.0), Sense::hover());
            ui.painter()
                .rect_filled(rect, 6, Color32::from_rgb(240, 244, 247));
            let fill = match key.as_str() {
                "high" => Color32::from_rgb(207, 100, 112),
                "medium" => Color32::from_rgb(212, 171, 107),
                "low" => Color32::from_rgb(122, 154, 193),
                _ => ACCENT,
            };
            if count > 0 {
                let mut filled = rect;
                filled.max.x = filled.min.x + rect.width() * count as f32 / max;
                ui.painter().rect_filled(filled, 6, fill);
            }
            ui.label(text(number(count), 12.0, INK).strong());
        });
    }
}
