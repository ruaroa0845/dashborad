use super::{empty, file_path, icons, notice, theme::*, ViewActions};
use crate::model::{Action, UiModel};
use eframe::egui::{self, Align, Color32, Frame, Layout, Margin, Stroke, Ui};
use serde_json::Value;

pub fn show(
    context: &egui::Context,
    model: &UiModel,
    chosen: &mut String,
    output: &mut ViewActions,
) {
    let screen = context.content_rect();
    let width = 608.0_f32.min(screen.width() - 32.0);
    let body_height = (screen.height() * 0.85 - 125.0).max(200.0);
    let modal_id = egui::Id::new("file-details-modal");
    let area = egui::Modal::default_area(modal_id).anchor(
        egui::Align2::RIGHT_CENTER,
        egui::vec2(-screen.width() * 0.045, 0.0),
    );
    let response = egui::Modal::new(modal_id)
        .area(area)
        .backdrop_color(Color32::from_rgba_unmultiplied(16, 44, 53, 26))
        .frame(
            Frame::new()
                .fill(Color32::WHITE)
                .corner_radius(14)
                .stroke(Stroke::new(1.0_f32, LINE)),
        )
        .show(context, |ui| {
            ui.set_width(width);
            Frame::new()
                .fill(Color32::from_rgb(245, 248, 250))
                .corner_radius(egui::CornerRadius {
                    nw: 14,
                    ne: 14,
                    sw: 0,
                    se: 0,
                })
                .inner_margin(Margin::symmetric(24, 18))
                .show(ui, |ui| {
                    ui.set_width(width - 48.0);
                    ui.horizontal(|ui| {
                        ui.vertical(|ui| {
                            ui.label(text("FILE DETAILS", 8.0, MUTED));
                            ui.label(text("상세보기", 17.0, INK).strong());
                        });
                        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                            if ui
                                .add(egui::Button::new(text("×", 22.0, MUTED)).frame(false))
                                .on_hover_text("상세보기 닫기")
                                .clicked()
                            {
                                output.actions.push(Action::CloseDetail);
                            }
                        });
                    });
                });
            Frame::new().inner_margin(Margin::same(24)).show(ui, |ui| {
                ui.set_width(width - 48.0);
                egui::ScrollArea::vertical()
                    .id_salt(("detail-scroll", &model.selected_file))
                    .min_scrolled_height(body_height)
                    .max_height(body_height)
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        if model.detail_loading && model.detail.is_null() {
                            empty(ui, "상세 정보를 불러오는 중…", "");
                        } else if let Some(error) = &model.detail_error {
                            notice(ui, error, true);
                            if ui.button("다시 시도").clicked() {
                                output.actions.push(Action::Refresh);
                            }
                        } else if !model.detail.is_null() {
                            contents(ui, &model.detail, chosen, output);
                        }
                    });
            });
        });
    if response.should_close() {
        output.actions.push(Action::CloseDetail);
    }
}

fn contents(ui: &mut Ui, data: &Value, chosen: &mut String, output: &mut ViewActions) {
    let directory = data["is_directory"].as_bool();
    let deleted = value(data, "file_status") == "deleted";
    ui.horizontal(|ui| {
        icons::show(
            ui,
            if directory == Some(true) {
                icons::Icon::Folder
            } else {
                icons::Icon::File
            },
            18.0,
            MUTED,
        );
        ui.label(text(value(data, "file_name"), 16.0, INK).strong());
    });
    ui.label(text(file_path(data), 11.0, MUTED));
    ui.add_space(16.0);
    ui.horizontal_wrapped(|ui| {
        if deleted {
            chip(ui, "삭제됨", RED);
        }
        let size = match directory {
            Some(true) => "폴더".into(),
            Some(false) => file_size(&data["file_size_bytes"]),
            None => "종류 미확인".into(),
        };
        chip(ui, size, MUTED);
        chip(ui, scan_name(value(data, "scan_status")), MUTED);
        chip(ui, format!("관측 {}", date(&data["observed_at"])), MUTED);
    });
    ui.add_space(14.0);
    ui.separator();
    ui.add_space(12.0);
    if deleted {
        Frame::new().fill(Color32::from_rgb(250, 245, 246)).corner_radius(8)
            .stroke(Stroke::new(1.0_f32, Color32::from_rgb(236, 221, 226)))
            .inner_margin(Margin::same(15)).show(ui, |ui| {
                ui.label(text("삭제된 경로의 보존 기록입니다.", 12.0, RED).strong());
                metadata(ui, "마지막 경로", file_path(data));
                metadata(ui, "삭제 시각", &date(&data["deleted_at"]));
                muted(ui, "삭제 전 마지막 검사 결과를 보존합니다. 파일 삭제는 탐지 후보의 최종 판별을 의미하지 않습니다.");
            });
        ui.add_space(18.0);
    }
    let parent = std::path::Path::new(file_path(data))
        .parent()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_else(|| "경로 정보 없음".into());
    let folder_path = value(&data["folder"], "folder_path");
    metadata(
        ui,
        "폴더 경로",
        if folder_path.is_empty() {
            &parent
        } else {
            folder_path
        },
    );
    let modified = if data["modified_at"].is_null() {
        "미제공".into()
    } else {
        date(&data["modified_at"])
    };
    metadata(ui, "파일 수정 시각", &modified);
    if data["history_snapshot"] == true {
        metadata(ui, "변경 종류", value(data, "trigger"));
    }
    metadata(ui, "검사 시각", &date(&data["last_scanned_at"]));
    if data["history_snapshot"] == true {
        metadata(ui, "검사 ID", value(data, "scan_id"));
        muted(
            ui,
            "선택한 검사 당시 저장된 기록입니다. 이후 검사 결과와 구분하여 표시합니다.",
        );
    }
    ui.add_space(16.0);
    if data["changed_since_scan"] == true {
        muted(
            ui,
            "파일 변경 후 재검사 중 · 아래 결과는 이전 검사 기록입니다.",
        );
        ui.add_space(12.0);
    }
    let status = value(data, "scan_status");
    if matches!(
        status,
        "partial"
            | "failed"
            | "error"
            | "not_scanned"
            | "excluded"
            | "unsupported"
            | "needs_review"
    ) {
        let reason = data["reason"]
            .as_str()
            .filter(|reason| !reason.is_empty())
            .unwrap_or(if status == "needs_review" {
                "일부 결과에 추가 검토가 필요합니다. 아래 사유를 확인하세요."
            } else if status == "excluded" {
                "판별 정책에 따라 검사에서 제외되었습니다."
            } else {
                "검사 결과가 전달되지 않았습니다."
            });
        let reason = visible_reason(reason);
        if !reason.is_empty() {
            notice(
                ui,
                &reason,
                matches!(status, "failed" | "error" | "partial"),
            );
        }
        ui.add_space(16.0);
    }
    let mut reasons = std::collections::BTreeSet::new();
    for finding in data["findings"]
        .as_array()
        .map(Vec::as_slice)
        .unwrap_or_default()
    {
        if finding["review_required"] == true
            || matches!(
                value(finding, "status"),
                "needs_review" | "failed" | "error"
            )
        {
            for reason in finding["review_reasons"]
                .as_array()
                .map(Vec::as_slice)
                .unwrap_or_default()
            {
                if let Some(reason) = reason.as_str() {
                    let visible = visible_reason(reason);
                    if !visible.is_empty() {
                        reasons.insert(reason_text(&visible).to_owned());
                    }
                }
            }
            let visible = visible_reason(value(finding, "error_code"));
            if !visible.is_empty() {
                reasons.insert(reason_text(&visible).to_owned());
            }
        }
    }
    if !reasons.is_empty() {
        metadata(
            ui,
            "검토 / 실패 사유",
            &reasons.into_iter().collect::<Vec<_>>().join(" · "),
        );
    }
    let findings = data["findings"]
        .as_array()
        .map(Vec::as_slice)
        .unwrap_or_default()
        .iter()
        .filter(|finding| {
            finding["decision_source"] == "jev"
                && finding["status"] == "classified"
                && matches!(
                    finding["risk_level"].as_str(),
                    Some("high" | "medium" | "low")
                )
        })
        .collect::<Vec<_>>();
    if findings.is_empty() {
        chosen.clear();
        metadata(ui, "검사 상태", scan_name(status));
        metadata(ui, "마지막 검사", &date(&data["last_scanned_at"]));
        if directory == Some(true) {
            empty(ui, "폴더 정보", "폴더 자체는 내용 검사 대상이 아닙니다.");
        } else if status == "completed" {
            empty(
                ui,
                "표시할 확정 탐지 결과가 없습니다.",
                "최종 판정이 완료된 low · medium · high 결과만 표시합니다.",
            );
        } else {
            empty(
                ui,
                if matches!(status, "scanning" | "awaiting_jev" | "pending") {
                    "검사 중입니다."
                } else {
                    "표시할 확정 탐지 결과가 없습니다."
                },
                "미검사·실패·제외 상태는 안전 판정을 의미하지 않습니다.",
            );
        }
        return;
    }
    if !findings
        .iter()
        .any(|finding| value(finding, "finding_id") == chosen)
    {
        *chosen = value(&findings[0], "finding_id").to_owned();
    }
    ui.horizontal_wrapped(|ui| {
        for (index, finding) in findings.iter().enumerate() {
            let active = value(finding, "finding_id") == chosen;
            let button = egui::Button::new(text(
                format!("탐지 {} · {}", index + 1, value(finding, "title")),
                11.0,
                if active { ACCENT } else { INK },
            ))
            .fill(if active { SELECTED } else { Color32::WHITE })
            .stroke(Stroke::new(1.0_f32, if active { ACCENT } else { LINE }));
            if ui.add(button).clicked() {
                *chosen = value(finding, "finding_id").to_owned();
            }
        }
    });
    ui.add_space(18.0);
    let finding = findings
        .iter()
        .find(|finding| value(finding, "finding_id") == chosen)
        .unwrap_or(&findings[0]);
    if data["history_snapshot"] != true {
        heading(ui, "조치 상태 · 로컬 관리");
        let local_status = finding["local_status"].as_str().unwrap_or("open");
        metadata(ui, "현재 상태", action_name(local_status));
        ui.horizontal_wrapped(|ui| {
            for (status, label) in [
                ("open", "다시 열기"),
                ("in_progress", "검토 중"),
                ("resolved", "해결됨"),
                ("false_positive", "오탐"),
            ] {
                let enabled = match local_status {
                    "open" => status != "open",
                    "in_progress" => status != "in_progress",
                    "resolved" | "false_positive" => status == "open",
                    _ => false,
                };
                if ui
                    .add_enabled(
                        enabled && !value(finding, "action_key").is_empty(),
                        egui::Button::new(label),
                    )
                    .clicked()
                {
                    output.actions.push(Action::SetLocalAction {
                        key: value(finding, "action_key").into(),
                        status: status.into(),
                        version: finding["local_version"].as_u64().unwrap_or(0),
                    });
                }
            }
        });
        muted(
            ui,
            "로컬 관리용 상태입니다. 엔진의 최종 판정이나 실제 파일은 변경하지 않습니다.",
        );
        if let Some(history) = finding["local_history"]
            .as_array()
            .filter(|v| !v.is_empty())
        {
            egui::CollapsingHeader::new("조치 상태 변경 이력").show(ui, |ui| {
                for change in history.iter().rev() {
                    muted(
                        ui,
                        format!(
                            "{} → {} · {}",
                            action_name(value(change, "from")),
                            action_name(value(change, "to")),
                            date(&change["at"])
                        ),
                    );
                }
            });
        }
        ui.add_space(18.0);
    }
    heading(ui, "검사 결과");
    ui.add_space(8.0);
    metadata(
        ui,
        "탐지 유형",
        &format!(
            "{} · {}",
            category_name(value(finding, "category")),
            value(finding, "title")
        ),
    );
    metadata(
        ui,
        "탐지 위치",
        &finding["line"]
            .as_u64()
            .map(|line| {
                format!(
                    "{line}번째 줄 · {}열",
                    finding["column"].as_u64().unwrap_or(1)
                )
            })
            .unwrap_or_else(|| "위치 정보 없음".into()),
    );
    metadata(ui, "마지막 검사", &date(&data["last_scanned_at"]));
    ui.add_space(20.0);
    Frame::new()
        .fill(Color32::from_rgb(244, 247, 250))
        .corner_radius(8)
        .inner_margin(Margin::symmetric(15, 13))
        .show(ui, |ui| {
            ui.set_min_width((ui.available_width() - 1.0).max(0.0));
            muted(ui, "마스킹된 탐지 내용");
            ui.add_space(5.0);
            ui.label(
                text(
                    if value(finding, "masked_snippet").is_empty() {
                        "저장된 마스킹 정보가 없습니다."
                    } else {
                        value(finding, "masked_snippet")
                    },
                    12.0,
                    Color32::from_rgb(50, 73, 91),
                )
                .monospace(),
            );
        });
    ui.add_space(12.0);
    if let Some(lines) = finding["context"]["lines_masked"]
        .as_array()
        .filter(|lines| !lines.is_empty())
    {
        egui::CollapsingHeader::new("마스킹된 주변 코드").show(ui, |ui| {
            let start = finding["context"]["start_line"].as_u64().unwrap_or(1);
            for (index, line) in lines.iter().enumerate() {
                ui.label(
                    text(
                        format!("{}  {}", start + index as u64, line.as_str().unwrap_or("")),
                        11.0,
                        INK,
                    )
                    .monospace(),
                );
            }
            if finding["context"]["truncated"] == true {
                muted(ui, "주변 코드 일부만 보존되었습니다.");
            }
        });
    }
    ui.add_space(18.0);

    let has_decision = value(finding, "decision_source") == "jev";
    metadata_ui(ui, "최종 위험도", |ui| {
        if !has_decision || value(finding, "severity").is_empty() {
            muted(ui, absent_risk_name(finding));
        } else {
            badge(ui, value(finding, "severity"));
            if finding["review_required"] == true {
                muted(ui, "검토 필요");
            }
        }
    });
    metadata_ui(ui, "판별 상태", |ui| {
        ui.horizontal_wrapped(|ui| {
            chip(
                ui,
                decision_name(value(finding, "status")),
                if finding["review_required"] == true {
                    AMBER
                } else {
                    ACCENT
                },
            );
            if finding["read_only"] == true {
                muted(ui, "읽기 전용");
            }
        });
    });
    if has_decision {
        metadata(
            ui,
            "유효성 판별",
            reality_name(value(finding, "secret_reality")),
        );
        metadata(
            ui,
            "최종 유형",
            secret_type_name(value(finding, "secret_type")),
        );
    }
    if let Some(reasons) = finding["review_reasons"].as_array() {
        let reasons = reasons
            .iter()
            .filter_map(Value::as_str)
            .map(visible_reason)
            .filter(|s| !s.is_empty())
            .collect::<Vec<_>>()
            .join(" · ");
        if !reasons.is_empty() {
            metadata(ui, "검토 사유", &reasons);
        }
    }
    if !visible_reason(value(finding, "error_code")).is_empty() {
        let code = value(finding, "error_code");
        let description = reason_text(code);
        if description != code {
            metadata(ui, "오류 내용", description);
        }
        metadata(ui, "오류 코드", code);
    }
    muted(
        ui,
        if !has_decision {
            "정규식 검사 결과입니다. 최종 판별 결과가 없습니다."
        } else if finding["review_required"] == true {
            "추가 검토가 필요한 결과입니다. 미판정 위험도를 낮은 위험으로 해석하지 마세요."
        } else if matches!(
            value(finding, "secret_reality"),
            "likely_test" | "placeholder"
        ) {
            "테스트용 또는 입력 예시로 판별되어 사용 위험 건수에 포함되지 않습니다."
        } else {
            "저장된 판별 결과입니다. 검사 시점 이후의 파일 변경은 차후 검사에 반영됩니다."
        },
    );
    ui.add_space(18.0);
    ui.separator();
    ui.add_space(12.0);
    ui.label(text("검사 기록 정보", 12.0, INK).strong());
    metadata(ui, "탐지 시각", &date(&finding["detected_at"]));
    metadata(ui, "검사 ID", value(finding, "run_id"));
}

fn metadata(ui: &mut Ui, label: &str, value: &str) {
    metadata_ui(ui, label, |ui| {
        ui.label(text(value, 12.0, INK));
    });
}

fn metadata_ui(ui: &mut Ui, label: &str, content: impl FnOnce(&mut Ui)) {
    ui.horizontal_top(|ui| {
        super::cell(ui, 130.0, 28.0, |ui| {
            ui.label(text(label, 12.0, MUTED));
        });
        ui.add_space(6.0);
        ui.vertical(|ui| {
            ui.set_min_height(28.0);
            content(ui);
        });
    });
    ui.separator();
}

fn file_size(value: &Value) -> String {
    match value.as_u64() {
        None => "크기 정보 없음".into(),
        Some(size) if size < 1024 => format!("{size} B"),
        Some(size) if size < 1_048_576 => format!("{:.1} KB", size as f64 / 1024.0),
        Some(size) => format!("{:.1} MB", size as f64 / 1_048_576.0),
    }
}
