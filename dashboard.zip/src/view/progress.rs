use super::*;

const SEGMENTS: [(&str, &str, Color32); 6] = [
    ("completed", "완료", Color32::from_rgb(58, 171, 136)),
    ("file_running", "파일 검사", Color32::from_rgb(70, 123, 232)),
    ("jev_running", "JEV 검사", Color32::from_rgb(146, 112, 217)),
    ("failed", "실패", Color32::from_rgb(220, 115, 124)),
    ("review", "검토 필요", Color32::from_rgb(223, 182, 86)),
    ("other", "결과 없음·제외", Color32::from_rgb(220, 226, 233)),
];

pub(super) fn show(ui: &mut Ui, model: &UiModel) {
    let counts = &model.health["scan_progress"]["counts"];
    let count = |key: &str| counts[key].as_u64().unwrap_or(0);
    let total: u64 = SEGMENTS.iter().map(|(key, _, _)| count(key)).sum();
    let active = count("file_running") + count("jev_running");
    // Engine failures are file states; only read failures make the displayed snapshot stale.
    let error = model.error.is_some() || model.health["log_error"].is_string();
    let title = if error {
        "갱신 실패 · 이전 상태".into()
    } else if active > 0 {
        format!("검사 중 {}개", number(active))
    } else if total > 0 {
        "현재 검사 현황".into()
    } else {
        "검사 결과 대기".into()
    };
    ui.label(text(title, 11.0, INK));
    if total == 0 {
        return;
    }
    let (rect, response) =
        ui.allocate_exact_size(egui::vec2(ui.available_width(), 7.0), Sense::hover());
    ui.painter().rect_filled(rect, 3, LINE);
    let mut left = rect.left();
    for (key, _, color) in SEGMENTS {
        let width = rect.width() * count(key) as f32 / total as f32;
        if width > 0.0 {
            ui.painter().rect_filled(
                egui::Rect::from_min_max(
                    egui::pos2(left, rect.top()),
                    egui::pos2(left + width, rect.bottom()),
                ),
                0,
                color,
            );
            left += width;
        }
    }
    response.on_hover_text(format!("현재 파일 {}개 · 전체 경로 기준", number(total)));
    ui.horizontal_wrapped(|ui| {
        ui.spacing_mut().item_spacing = egui::vec2(8.0, 2.0);
        for (key, label, color) in SEGMENTS {
            let count = count(key);
            if count == 0 {
                continue;
            }
            let mut label_text = egui::text::LayoutJob::default();
            label_text.append(
                "● ",
                0.0,
                egui::TextFormat {
                    font_id: egui::FontId::proportional(9.0),
                    color,
                    ..Default::default()
                },
            );
            label_text.append(
                &format!("{label} {}", number(count)),
                0.0,
                egui::TextFormat {
                    font_id: egui::FontId::proportional(10.0),
                    color: MUTED,
                    ..Default::default()
                },
            );
            ui.add(egui::Label::new(label_text).wrap_mode(egui::TextWrapMode::Extend));
        }
    });
}
