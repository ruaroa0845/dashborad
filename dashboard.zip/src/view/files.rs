use super::*;

impl DashboardView {
    pub(super) fn files(&mut self, ui: &mut Ui, model: &UiModel, output: &mut ViewActions) {
        let mut filters = model.filters.clone();
        let mut changed = false;
        if !filters.folder.is_empty() {
            ui.horizontal(|ui| {
                if ui.button("전체 파일").clicked() {
                    output.actions.push(Action::ClearFolder);
                }
                muted(ui, "›");
                icons::show(ui, icons::Icon::Folder, 16.0, ACCENT);
                ui.add(egui::Label::new(text(&filters.folder, 13.0, INK)).truncate())
                    .on_hover_text(&filters.folder);
            });
            ui.add_space(14.0);
        }
        Frame::new()
            .fill(Color32::WHITE)
            .corner_radius(10)
            .inner_margin(Margin::symmetric(18, 13))
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                ui.horizontal(|ui| {
                    icons::show(ui, icons::Icon::Search, 23.0, MUTED);
                    let search = ui.add_sized(
                        [(ui.available_width() - 70.0).max(100.0), 40.0],
                        egui::TextEdit::singleline(&mut self.search)
                            .id_salt("file-search")
                            .font(egui::FontId::proportional(16.0))
                            .frame(false)
                            .hint_text("파일명, 폴더명 또는 전체 경로 검색…"),
                    );
                    if self.focus_search {
                        search.request_focus();
                        self.focus_search = false;
                    }
                    muted(ui, "/");
                    let enter = search.lost_focus()
                        && ui.input(|input| input.key_pressed(egui::Key::Enter));
                    if ui
                        .add(
                            egui::Button::new(text("검색", 12.0, Color32::WHITE).strong())
                                .fill(ACCENT),
                        )
                        .clicked()
                        || enter
                    {
                        changed = true;
                    }
                });
            });
        ui.add_space(16.0);
        ui.allocate_ui_with_layout(
            egui::vec2(ui.available_width(), 32.0),
            Layout::left_to_right(Align::Min).with_main_wrap(true),
            |ui| {
                // Use identical metrics even when the OS replaces egui's default style.
                ui.spacing_mut().interact_size.y = 32.0;
                ui.spacing_mut().button_padding = egui::vec2(10.0, 6.0);
                ui.style_mut().override_font_id = Some(egui::FontId::proportional(12.0));
                if filters.folder.is_empty() {
                    changed |= combo(
                        ui,
                        "kind",
                        &mut filters.kind,
                        &[("", "모든 경로"), ("file", "파일"), ("folder", "폴더")],
                        100.0,
                    );
                }
                changed |= combo(
                    ui,
                    "file-status",
                    &mut filters.file_status,
                    &[
                        ("", "전체 파일 상태"),
                        ("present", "현재 파일"),
                        ("deleted", "삭제된 파일"),
                    ],
                    118.0,
                );
                changed |= combo(
                    ui,
                    "severity",
                    &mut filters.severity,
                    &[
                        ("", "모든 위험도"),
                        ("high", "High"),
                        ("medium", "Medium"),
                        ("low", "Low"),
                        ("unassessed", "위험도 미판정"),
                    ],
                    110.0,
                );
                changed |= combo(
                    ui,
                    "scan-status",
                    &mut filters.scan_status,
                    &[
                        ("", "모든 검사 상태"),
                        ("not_scanned", "검사 결과 없음"),
                        ("scanning", "검사 중"),
                        ("awaiting_jev", "검사 중"),
                        ("not_applicable", "검사 대상 아님"),
                        ("completed", "검사 완료"),
                        ("needs_review", "검토 필요"),
                        ("excluded", "검사 제외"),
                        ("partial", "부분 검사"),
                        ("failed", "검사 실패"),
                    ],
                    126.0,
                );
                changed |= combo(
                    ui,
                    "category",
                    &mut filters.category,
                    &[
                        ("", "모든 탐지 유형"),
                        ("secret", "Secret"),
                        ("pii", "개인정보"),
                        ("weak_crypto", "취약 암호화"),
                        ("environment", "로그·환경 파일"),
                    ],
                    124.0,
                );
                // Reset, label and selector use one fixed-height row and wrap together.
                ui.allocate_ui_with_layout(
                    egui::vec2(220.0, 32.0),
                    Layout::left_to_right(Align::Min),
                    |ui| {
                        if ui
                            .add_sized(
                                [56.0, 32.0],
                                egui::Button::new(text("초기화", 12.0, MUTED)).frame(false),
                            )
                            .clicked()
                        {
                            filters = Filters {
                                folder: filters.folder.clone(),
                                page_size: filters.page_size,
                                ..Filters::default()
                            };
                            self.search.clear();
                            changed = true;
                        }
                        ui.add_space(8.0);
                        ui.add_sized([26.0, 32.0], egui::Label::new(text("정렬", 12.0, MUTED)));
                        changed |= combo(
                            ui,
                            "sort",
                            &mut filters.sort,
                            &[("", "기본순"), ("risk", "위험도순"), ("name", "이름순")],
                            90.0,
                        );
                    },
                );
            },
        );
        ui.add_space(22.0);
        ui.horizontal(|ui| {
            ui.label(
                text(
                    if filters.folder.is_empty() {
                        "통합 경로 목록"
                    } else {
                        "폴더 내부 파일"
                    },
                    19.0,
                    INK,
                )
                .strong(),
            );
            chip(
                ui,
                number(model.files["total"].as_u64().unwrap_or(0)),
                ACCENT,
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                muted(
                    ui,
                    format!("데이터 기준 {}", date(&model.files["data_updated_at"])),
                );
            });
        });
        ui.add_space(16.0);
        card().inner_margin(Margin::same(18)).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal(|ui| {
                heading(ui, "경로별 상세 목록");
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    muted(
                        ui,
                        if filters.folder.is_empty() {
                            "폴더를 선택하면 내부 파일 목록을 표시합니다."
                        } else {
                            "파일을 선택하면 상세 정보를 확인할 수 있습니다."
                        },
                    )
                });
            });
            ui.add_space(16.0);
            let table_width = ui.available_width().max(740.0);
            egui::ScrollArea::horizontal()
                .id_salt("file-table-width")
                .show(ui, |ui| {
                    ui.set_width(table_width);
                    let width = table_width;
                    let columns = [
                        width * 0.45,
                        width * 0.17,
                        width * 0.11,
                        width * 0.15,
                        width * 0.08,
                    ];
                    table_header(
                        ui,
                        &columns,
                        &[
                            "이름 / 상세 경로",
                            "탐지 유형",
                            "위험도",
                            "검사 상태",
                            "후보",
                        ],
                    );
                    if let Some(rows) = model.files["items"].as_array() {
                        if rows.is_empty() {
                            empty(
                                ui,
                                if model.loading {
                                    "목록을 불러오는 중…"
                                } else {
                                    "일치하는 경로가 없습니다."
                                },
                                "검색어나 필터를 변경해 주세요.",
                            );
                        }
                        for (index, file) in rows.iter().enumerate() {
                            let id = value(file, "file_id");
                            let selected = model.selected_file.as_deref() == Some(id);
                            let path = file_path(file);
                            let response = Frame::new()
                                .fill(if selected {
                                    SELECTED
                                } else if index % 2 == 0 {
                                    SOFT
                                } else {
                                    Color32::WHITE
                                })
                                .corner_radius(6)
                                .inner_margin(Margin::symmetric(10, 10))
                                .show(ui, |ui| {
                                    ui.set_width(table_width - 20.0);
                                    ui.spacing_mut().item_spacing.x = 0.0;
                                    ui.horizontal(|ui| {
                                        cell(ui, columns[0] - 14.0, 48.0, |ui| {
                                            ui.horizontal(|ui| {
                                                let directory =
                                                    file["is_directory"].as_bool() == Some(true);
                                                icons::show(
                                                    ui,
                                                    if directory {
                                                        icons::Icon::Folder
                                                    } else {
                                                        icons::Icon::File
                                                    },
                                                    16.0,
                                                    if directory {
                                                        Color32::from_rgb(179, 146, 88)
                                                    } else {
                                                        MUTED
                                                    },
                                                );
                                                ui.add_space(7.0);
                                                ui.add(
                                                    egui::Label::new(
                                                        text(value(file, "file_name"), 14.0, INK)
                                                            .strong(),
                                                    )
                                                    .truncate(),
                                                );
                                            });
                                            ui.add(
                                                egui::Label::new(text(path, 11.0, MUTED))
                                                    .truncate(),
                                            );
                                        });
                                        cell(ui, columns[1], 48.0, |ui| {
                                            let categories = file["categories"]
                                                .as_array()
                                                .map(|values| {
                                                    values
                                                        .iter()
                                                        .filter_map(Value::as_str)
                                                        .map(category_name)
                                                        .collect::<Vec<_>>()
                                                        .join(" · ")
                                                })
                                                .unwrap_or_default();
                                            ui.add(
                                                egui::Label::new(text(
                                                    if categories.is_empty() {
                                                        "—"
                                                    } else {
                                                        &categories
                                                    },
                                                    11.0,
                                                    MUTED,
                                                ))
                                                .wrap(),
                                            );
                                        });
                                        cell(ui, columns[2], 48.0, |ui| {
                                            badge(ui, value(file, "final_severity"))
                                        });
                                        cell(ui, columns[3], 48.0, |ui| {
                                            scan_label(ui, value(file, "scan_status"));
                                            if value(file, "file_status") == "deleted" {
                                                ui.label(text("삭제됨", 10.0, RED));
                                            }
                                        });
                                        cell(ui, columns[4], 48.0, |ui| {
                                            let count = file["finding_count"].as_u64().unwrap_or(0);
                                            ui.label(text(
                                                if count > 0 {
                                                    format!("{}건", number(count))
                                                } else {
                                                    "—".into()
                                                },
                                                12.0,
                                                ACCENT,
                                            ));
                                            if let Some(review) = file["review_required_count"]
                                                .as_u64()
                                                .filter(|count| *count > 0)
                                            {
                                                ui.label(text(
                                                    format!("검토 {review}"),
                                                    10.0,
                                                    AMBER,
                                                ));
                                            }
                                        });
                                        muted(ui, "›");
                                    });
                                })
                                .response
                                .interact(Sense::click());
                            if response.clone().on_hover_text(path).clicked() {
                                output.actions.push(
                                    if file["is_directory"].as_bool() == Some(true) {
                                        Action::SelectFolder(path.to_owned())
                                    } else {
                                        Action::SelectFile(id.to_owned())
                                    },
                                );
                            }
                            ui.add_space(5.0);
                        }
                    }
                });
            ui.add_space(12.0);
            ui.separator();
            ui.add_space(12.0);
            ui.horizontal(|ui| {
                let start = model.files["offset"].as_u64().unwrap_or(0);
                let count = model.files["items"].as_array().map_or(0, Vec::len) as u64;
                let total = model.files["total"].as_u64().unwrap_or(0);
                muted(
                    ui,
                    if count == 0 {
                        format!("0 / {}개", number(total))
                    } else {
                        format!("{}–{} / {}개", start + 1, start + count, number(total))
                    },
                );
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if ui
                        .add_enabled(
                            model.next_cursor.is_some() && !model.loading,
                            egui::Button::new("›"),
                        )
                        .clicked()
                    {
                        output.actions.push(Action::NextPage);
                    }
                    ui.label(text(model.page_number.to_string(), 12.0, MUTED));
                    if ui
                        .add_enabled(
                            model.page_number > 1 && !model.loading,
                            egui::Button::new("‹"),
                        )
                        .clicked()
                    {
                        output.actions.push(Action::PreviousPage);
                    }
                    egui::ComboBox::from_id_salt("page-size")
                        .selected_text(filters.page_size.to_string())
                        .width(60.0)
                        .show_ui(ui, |ui| {
                            for size in [10, 20, 50, 100] {
                                changed |= ui
                                    .selectable_value(
                                        &mut filters.page_size,
                                        size,
                                        size.to_string(),
                                    )
                                    .changed();
                            }
                        });
                    muted(ui, "페이지당");
                });
            });
        });
        ui.add_space(12.0);
        ui.label(text("ⓘ 저장된 판별 결과를 표시합니다. 등급 없음·미검사·실패·제외는 낮은 위험 판정이 아닙니다. 후보별 판별과 검토 사유는 상세보기에서 확인하세요.", 10.0, MUTED));
        if changed {
            filters.q = self.search.trim().to_owned();
            output.actions.push(Action::SetFilters(filters));
        }
    }
}
