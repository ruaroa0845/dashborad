use super::*;

pub(super) fn show(ui: &mut Ui, model: &UiModel, output: &mut ViewActions) {
    card().show(ui, |ui| {
        heading(ui, "파일별 검사 이력");
        muted(ui, "언제 어떤 파일을 검사했고 무엇을 발견했는지 확인합니다. 상세보기는 그 검사 당시의 저장된 결과입니다.");
        if model.scans["history"]["dropped"].as_u64().unwrap_or(0) > 0 {
            muted(ui, "보관 범위를 벗어난 이력은 목록에서 제외됩니다.");
        }
        ui.add_space(16.0);
        let width = ui.available_width().max(760.0);
        egui::ScrollArea::horizontal().id_salt("scan-table-width").show(ui, |ui| {
            ui.set_width(width);
            let widths = [width*0.18, width*0.30, width*0.16, width*0.13, width*0.11, width*0.12];
            table_header(ui, &widths, &["검사 시각", "파일 / 경로", "변경 종류", "검사 상태", "확정 탐지", "검사 기록"]);
            let rows = model.scans["items"].as_array().map(Vec::as_slice).unwrap_or_default();
            if rows.is_empty() {empty(ui, "저장된 검사 이력이 없습니다.", "이전 결과를 보려면 검사별 로그가 보관되어 있어야 합니다.");}
            for (index,row) in rows.iter().enumerate() {
                Frame::new().fill(if index%2==0 {SOFT} else {Color32::WHITE}).corner_radius(6)
                    .inner_margin(Margin::symmetric(8,14)).show(ui,|ui| {
                    ui.set_width(width-16.0);
                    ui.horizontal(|ui| {
                        ui.spacing_mut().item_spacing.x=0.0;
                        cell(ui,widths[0]-8.0,54.0,|ui| {
                            let time=if row["started_at"].is_null(){&row["completed_at"]}else{&row["started_at"]};
                            muted(ui,date(time));
                        });
                        cell(ui,widths[1],54.0,|ui| {
                            ui.add(egui::Label::new(text(value(row,"file_name"),12.0,INK).strong()).truncate());
                            ui.add(egui::Label::new(text(value(row,"path"),10.0,MUTED)).truncate()).on_hover_text(value(row,"path"));
                        });
                        cell(ui,widths[2],54.0,|ui| {muted(ui,value(row,"trigger"));});
                        cell(ui,widths[3],54.0,|ui| {scan_label(ui,value(row,"status"));});
                        cell(ui,widths[4],54.0,|ui| {
                            ui.label(text(format!("{}건",number(row["confirmed_count"].as_u64().unwrap_or(0))),12.0,INK));
                        });
                        cell(ui,widths[5]-8.0,54.0,|ui| {
                            if ui.add_enabled(row["detail"].is_object(),egui::Button::new("상세보기")).clicked() {
                                output.actions.push(Action::SelectScan(row["detail"].clone()));
                            }
                        });
                    });
                });
                ui.add_space(6.0);
            }
        });
    });
}
