//! 실제 수집 목록과 검사 결과를 표시하는 대시보드 화면입니다.
mod criteria;
mod detail;
mod files;
mod layout;
mod overview;
mod progress;
mod scans;

mod icons;
mod theme;

use crate::model::{Action, Filters, UiModel, View};
use eframe::egui::{self, Align, Color32, Frame, Layout, Margin, Sense, Stroke, Ui};
use serde_json::Value;
use theme::*;

#[derive(Default)]
pub struct ViewActions {
    pub actions: Vec<Action>,
    pub stop_requested: bool,
}

pub struct DashboardView {
    search: String,
    applied_query: String,
    chosen_finding: String,
    detail_file: Option<String>,
    criteria_expanded: [bool; 4],
    focus_search: bool,
}

impl Default for DashboardView {
    fn default() -> Self {
        Self {
            search: String::new(),
            applied_query: String::new(),
            chosen_finding: String::new(),
            detail_file: None,
            criteria_expanded: [true; 4],
            focus_search: false,
        }
    }
}

impl DashboardView {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn configure(context: &egui::Context) {
        theme::configure(context);
    }

    pub fn show(&mut self, context: &egui::Context, model: &UiModel) -> ViewActions {
        let mut output = ViewActions::default();
        if self.applied_query != model.filters.q {
            self.search.clone_from(&model.filters.q);
            self.applied_query.clone_from(&model.filters.q);
        }
        if self.detail_file != model.selected_file {
            self.detail_file.clone_from(&model.selected_file);
            self.chosen_finding.clear();
        }
        if model.selected_file.is_none()
            && !context.wants_keyboard_input()
            && context.input_mut(|input| input.consume_key(egui::Modifiers::NONE, egui::Key::Slash))
        {
            self.focus_search = true;
            output.actions.push(Action::SetView(View::Files));
        }
        self.sidebar(context, model, &mut output);
        self.topbar(context, model, &mut output);
        let compact = context.content_rect().width() <= 1150.0;
        egui::CentralPanel::default()
            .frame(Frame::new().fill(BACKGROUND).inner_margin(Margin {
                left: if compact { 24 } else { 32 },
                right: if compact { 24 } else { 32 },
                top: if compact { 25 } else { 29 },
                bottom: 20,
            }))
            .show(context, |ui| {
                egui::ScrollArea::vertical()
                    .id_salt(("dashboard-page", view_key(model.view)))
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        ui.set_width(ui.available_width().min(1640.0));
                        page_heading(ui, model.view, &model.health);
                        let failure = model
                            .error
                            .as_deref()
                            .or_else(|| model.health["log_error"].as_str())
                            .or_else(|| model.health["engine_error"].as_str())
                            .or_else(|| {
                                matches!(value(&model.health, "status"), "failed" | "error")
                                    .then(|| value(&model.health, "message"))
                                    .filter(|message| !message.is_empty())
                            });
                        if let Some(message) = failure {
                            notice(ui, message, true);
                            ui.add_space(16.0);
                        }
                        if let Some(message) = model.health["log_notice"].as_str() {
                            notice(ui, message, false);
                            ui.add_space(16.0);
                        }
                        match model.view {
                            View::Files => self.files(ui, model, &mut output),
                            View::Overview => overview::show(
                                ui,
                                model,
                                &mut output,
                                &mut self.chosen_finding,
                                &mut self.detail_file,
                            ),
                            View::Scans => scans::show(ui, model, &mut output),
                            View::Criteria => criteria::show(ui, &mut self.criteria_expanded),
                        }
                        ui.add_space(38.0);
                        ui.separator();
                        ui.add_space(10.0);
                        ui.horizontal(|ui| {
                            muted(ui, "SecretWatch · 로컬 보안 워크스페이스");
                            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                muted(ui, "자동 갱신 2초")
                            });
                        });
                    });
            });
        if model.selected_file.is_some() {
            detail::show(context, model, &mut self.chosen_finding, &mut output);
        }
        output
    }
}

fn combo(ui: &mut Ui, id: &str, selected: &mut String, items: &[(&str, &str)], width: f32) -> bool {
    let mut changed = false;
    let label = items
        .iter()
        .find(|(key, _)| *key == selected)
        .map_or("", |(_, label)| *label);
    egui::ComboBox::from_id_salt(id)
        .selected_text(label)
        .width(width)
        .show_ui(ui, |ui| {
            for (key, label) in items {
                changed |= ui
                    .selectable_value(selected, (*key).to_owned(), *label)
                    .changed();
            }
        });
    changed
}

fn view_key(view: View) -> &'static str {
    match view {
        View::Files => "FILES",
        View::Overview => "OVERVIEW",
        View::Scans => "SCAN HISTORY",
        View::Criteria => "RISK CRITERIA",
    }
}

fn page_heading(ui: &mut Ui, view: View, health: &Value) {
    let (title, description) = match view {
        View::Files => (
            "통합 경로 목록",
            "SDK에서 수집한 파일과 폴더의 저장된 판별 결과와 검토 사유를 확인합니다.",
        ),
        View::Overview => (
            "위험 대시보드",
            "저장된 판별 결과의 위험도와 유형, 검토가 필요한 후보를 확인합니다.",
        ),
        View::Scans => (
            "검사 이력",
            "파일별 변경과 검사 결과를 확인하고 이전 검사 기록을 열어봅니다.",
        ),
        View::Criteria => ("위험도 기준표", ""),
    };
    ui.horizontal(|ui| {
        ui.label(text(format!("WORKSPACE / {}", view_key(view)), 9.0, MUTED));
    });
    ui.add_space(10.0);
    ui.horizontal(|ui| {
        ui.label(text(title, 28.0, INK).strong());
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            let response = ui
                .add(egui::Button::new(text("감시 대상 경로", 12.0, MUTED)).sense(Sense::hover()));
            let roots = health["roots"]
                .as_array()
                .map(|values| {
                    values
                        .iter()
                        .filter_map(Value::as_str)
                        .collect::<Vec<_>>()
                        .join("\n")
                })
                .unwrap_or_default();
            response.on_hover_text(roots);
        });
    });
    if !description.is_empty() {
        ui.label(text(description, 13.0, MUTED));
    }
    ui.add_space(24.0);
}

fn notice(ui: &mut Ui, message: &str, error: bool) {
    Frame::new()
        .fill(if error {
            Color32::from_rgb(255, 240, 241)
        } else {
            SOFT
        })
        .stroke(Stroke::new(
            1.0_f32,
            if error {
                Color32::from_rgb(241, 207, 213)
            } else {
                LINE
            },
        ))
        .corner_radius(7)
        .inner_margin(Margin::same(14))
        .show(ui, |ui| {
            ui.set_min_width((ui.available_width() - 1.0).max(0.0));
            ui.label(text(
                reason_text(message),
                12.0,
                if error { RED } else { MUTED },
            ))
            .on_hover_text(message);
        });
}

fn file_path(file: &Value) -> &str {
    if value(file, "file_status") == "deleted" {
        file["last_known_path"]
            .as_str()
            .unwrap_or_else(|| value(file, "path"))
    } else {
        value(file, "path")
    }
}

fn cell(ui: &mut Ui, width: f32, height: f32, contents: impl FnOnce(&mut Ui)) {
    ui.allocate_ui_with_layout(
        egui::vec2(width.max(20.0), height),
        Layout::top_down(Align::Min),
        |ui| {
            ui.set_width(width.max(20.0));
            ui.set_min_height(height);
            contents(ui);
        },
    );
}

fn table_header(ui: &mut Ui, widths: &[f32], labels: &[&str]) {
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 0.0;
        for (width, label) in widths.iter().zip(labels) {
            cell(ui, *width, 24.0, |ui| muted(ui, *label));
        }
    });
}

fn empty(ui: &mut Ui, title: &str, note: &str) {
    ui.add_space(42.0);
    ui.vertical_centered(|ui| {
        ui.label(text(title, 16.0, INK).strong());
        muted(ui, note);
    });
    ui.add_space(42.0);
}
