use super::*;
use serde::Deserialize;

#[derive(Deserialize)]
struct Snapshot {
    schema_version: u32,
    files: Vec<Item>,
    #[serde(default)]
    roots: Vec<PathBuf>,
}
#[derive(Deserialize)]
struct Item {
    file_id: String,
    #[serde(flatten)]
    file: FileInfo,
    #[serde(default)]
    changed_since_scan: bool,
}
impl DashboardState {
    pub fn set_sdk_json_source(&self, path: PathBuf, log_root: PathBuf) {
        let mut state = self.lock();
        state.sdk_json_path = Some(path);
        state.sdk_json_bytes = None;
        state.scan_store = Some(FileScanStore::new(log_root));
        state.persisted_fingerprint = None;
    }

    pub(super) fn refresh_sdk_json(&self, path: &Path) -> Result<(), String> {
        let bytes = std::fs::read(path)
            .map_err(|e| format!("SDK 목록 읽기 실패 ({}): {e}", path.display()))?;
        let mut snapshot: Snapshot =
            serde_json::from_slice(&bytes).map_err(|e| format!("SDK JSON 오류: {e}"))?;
        if snapshot.schema_version != 1 {
            return Err("SDK schema_version은 1이어야 합니다.".into());
        }
        let mut paths = std::collections::HashSet::new();
        for item in &mut snapshot.files {
            if !item.file.path.is_absolute() || !paths.insert(path_key(&item.file.path)) {
                return Err("SDK 목록에 상대 경로 또는 중복 경로가 있습니다.".into());
            }
            let (volume, reference) = item
                .file_id
                .split_once('_')
                .ok_or("file_id는 볼륨ID_FRN(16진수) 형식이어야 합니다.")?;
            let identity = askfile::FileIdentity {
                volume_serial_number: u32::from_str_radix(volume, 16)
                    .map_err(|_| "잘못된 볼륨 ID")?,
                file_reference_number: u64::from_str_radix(reference, 16)
                    .map_err(|_| "잘못된 FRN")?,
            };
            if item.file.identity.is_some_and(|id| id != identity) {
                return Err("file_id와 identity가 일치하지 않습니다.".into());
            }
            item.file.identity = Some(identity);
            item.file_id = crate::persisted::file_log_id(&item.file).unwrap();
        }
        let (store, capacity, previous, same_inventory) = {
            let state = self.lock();
            (
                state
                    .scan_store
                    .clone()
                    .ok_or("검사 로그 경로가 없습니다.")?,
                state.history_capacity,
                state.persisted_fingerprint.clone(),
                state.sdk_json_bytes.as_ref() == Some(&bytes),
            )
        };
        let fingerprint = store.fingerprint().map_err(|e| e.to_string())?;
        if same_inventory && previous.as_ref() == Some(&fingerprint) {
            return Ok(());
        }
        let saved = store.read_dashboard(&fingerprint, capacity);
        if !saved.errors.is_empty() {
            return Err(format!("검사 결과 읽기 실패: {}", saved.errors.join("; ")));
        }
        let received = now_ms();
        let mut state = self.lock();
        let mut entries = Vec::new();
        for item in snapshot.files {
            let record = (item.file.is_directory == Some(false))
                .then(|| saved.latest.get(&item.file_id))
                .flatten();
            let mut inspection = record
                .map(crate::persisted::inspection)
                .unwrap_or(Value::Null);
            if item.changed_since_scan && !inspection.is_null() {
                inspection["Ok"]["sdk_changed_since_scan"] = json!(true);
            }
            let row_id = format!("sdk:{}:{}", item.file_id, path_key(&item.file.path));
            let observed = state
                .files
                .get(&path_key(&item.file.path))
                .filter(|old| old.file == item.file)
                .map_or(received, |old| old.timestamp_ms);
            entries.push(Entry {
                row_id,
                sequence: entries.len() as u64 + 1,
                timestamp_ms: observed,
                file: item.file,
                inspection,
                inspection_timestamp_ms: record
                    .map(|r| r.processed_at.timestamp_millis().max(0) as u64),
                inspection_pending: item.changed_since_scan,
                content_revision: 0,
            });
        }
        state.files.clear();
        state.row_paths.clear();
        state.folders.clear();
        state.events.clear();
        state.history_row_counts.clear();
        state.counters = Counters::default();
        for entry in entries {
            state.counters.received += 1;
            if matches!(entry.file.event, Some(FileEvent::Deleted)) {
                state.events.push_back(entry);
            } else {
                if let Some(folder) = &entry.file.folder {
                    let group = state
                        .folders
                        .entry(path_key(&folder.folder_path))
                        .or_insert(FolderEntry {
                            info: folder.clone(),
                            members: 0,
                            sequence: entry.sequence,
                            timestamp_ms: received,
                        });
                    group.members += 1;
                }
                if entry.file.is_directory == Some(true) {
                    state.counters.current_directories += 1;
                } else {
                    state.counters.current_files += 1;
                }
                state
                    .row_paths
                    .insert(entry.row_id.clone(), path_key(&entry.file.path));
                state.files.insert(path_key(&entry.file.path), entry);
            }
        }
        state.counters.current_folders = state.folders.len();
        state.scan_history = saved.history.iter().map(persisted_entry).collect();
        state.scan_history_total = saved.total;
        if previous.as_ref() != Some(&fingerprint) && !saved.latest.is_empty() {
            state.result_received_at_ms = Some(received);
        }
        state.roots = snapshot.roots;
        state.sdk_json_bytes = Some(bytes);
        state.persisted_fingerprint = Some(fingerprint);
        state.updated_at_ms = Some(received);
        state.status = "running".into();
        state.initial_progress = json!({"phase":"complete", "total":state.counters.received, "completed":state.counters.received, "failed":0});
        state.revision = state.revision.wrapping_add(1);
        Ok(())
    }
}
