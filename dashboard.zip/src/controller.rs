// 저장된 검사 결과와 화면 조회를 별도 작업 스레드에서 갱신.

use crate::model::{Action, Filters, UiModel, View};
use crate::{api, DashboardState};
use serde_json::{json, Value};
use std::io;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex, TryLockError};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

const REFRESH_INTERVAL: Duration = Duration::from_secs(2);

#[derive(Clone)]
struct Request {
    generation: u64,
    view: View,
    filters: Filters,
    cursor: Option<String>,
    selected_file: Option<String>,
}

struct Response {
    generation: u64,
    health: Result<Value, String>,
    content: Result<Value, String>,
    detail: Result<Value, String>,
    refresh_error: Option<String>,
    refreshed_at: u64,
}

#[derive(Default)]
struct Slots {
    request: Option<Request>,
    response: Option<Response>,
}

#[derive(Default)]
struct Mailbox {
    slots: Mutex<Slots>,
    wake: Condvar,
    generation: AtomicU64,
    closed: AtomicBool,
}

impl Mailbox {
    fn current(&self, generation: u64) -> bool {
        !self.closed.load(Ordering::Acquire)
            && self.generation.load(Ordering::Acquire) == generation
    }

    fn submit(&self, request: Request) {
        self.generation.store(request.generation, Ordering::Release);
        self.slots
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .request = Some(request);
        self.wake.notify_one();
    }

    fn publish(&self, response: Response) -> bool {
        let mut slots = self.slots.lock().unwrap_or_else(|error| error.into_inner());
        if !self.current(response.generation) {
            return false;
        }
        slots.response = Some(response);
        true
    }
}

/// 파일 조회와 정렬은 작업 스레드에서 처리.
pub struct DashboardController {
    actions: Option<DashboardState>,
    pub model: UiModel,
    mailbox: Arc<Mailbox>,
    worker: Option<JoinHandle<()>>,
    generation: u64,
    previous_cursors: Vec<Option<String>>,
}

impl DashboardController {
    pub fn new(
        state: DashboardState,
        repaint: impl Fn() + Send + Sync + 'static,
    ) -> io::Result<Self> {
        let revisions = state.clone();
        let persisted = state.clone();
        let actions = state.clone();
        let mut controller = Self::with_source(
            move || persisted.refresh_persisted(),
            move || revisions.revision(),
            move |path| api::request(&state, path, "GET", None),
            repaint,
        )?;
        controller.actions = Some(actions);
        Ok(controller)
    }

    fn with_source(
        refresh: impl FnMut() -> Result<(), String> + Send + 'static,
        revision: impl Fn() -> u64 + Send + 'static,
        request: impl FnMut(&str) -> Value + Send + 'static,
        repaint: impl Fn() + Send + Sync + 'static,
    ) -> io::Result<Self> {
        let mailbox = Arc::new(Mailbox::default());
        let work = mailbox.clone();
        let worker = thread::Builder::new()
            .name("secretwatch-dashboard".into())
            .spawn(move || run_worker(work, refresh, revision, request, repaint))?;
        let mut data = Self {
            actions: None,
            model: UiModel::default(),
            mailbox,
            worker: Some(worker),
            generation: 0,
            previous_cursors: Vec::new(),
        };
        data.dispatch(Action::Refresh);
        Ok(data)
    }

    pub fn poll(&mut self) {
        let response = match self.mailbox.slots.try_lock() {
            Ok(mut slots) => slots.response.take(),
            Err(TryLockError::WouldBlock) => return,
            Err(TryLockError::Poisoned(error)) => error.into_inner().response.take(),
        };
        if let Some(response) = response {
            self.apply(response);
        }
    }

    pub fn dispatch(&mut self, action: Action) {
        match action {
            Action::SetLocalAction {
                key,
                status,
                version,
            } => {
                if let Some(state) = &self.actions {
                    if let Err(error) = state.set_local_action(&key, &status, version) {
                        self.model.detail_error = Some(error);
                        return;
                    }
                }
            }

            Action::SetView(view) if view != self.model.view => self.model.view = view,
            Action::SetFilters(mut filters) => {
                filters.page_size = filters.page_size.clamp(1, 1_000);
                if filters == self.model.filters {
                    return;
                }
                self.model.filters = filters;
                self.reset_page();
            }
            Action::SelectFolder(path) if self.model.filters.folder != path => {
                self.model.filters.folder = path;
                self.open_folder();
            }
            Action::ClearFolder if !self.model.filters.folder.is_empty() => {
                self.model.filters.folder.clear();
                self.open_folder();
            }
            Action::SelectScan(snapshot) => {
                self.model.selected_file = Some(format!("history:{}", snapshot["history_key"]));
                self.model.detail = snapshot;
                self.model.detail["history_snapshot"] = json!(true);
            }
            Action::SelectFile(id) if self.model.selected_file.as_ref() != Some(&id) => {
                self.model.selected_file = Some(id);
                self.model.detail = Value::Null;
            }
            Action::CloseDetail if self.model.selected_file.is_some() => {
                self.model.selected_file = None;
                self.model.detail = Value::Null;
            }
            Action::NextPage if !self.model.loading => {
                let Some(next) = self.model.next_cursor.take() else {
                    return;
                };
                self.previous_cursors.push(self.model.cursor.take());
                self.model.cursor = Some(next);
                self.model.page_number = self.previous_cursors.len() + 1;
            }
            Action::PreviousPage if !self.model.loading => {
                let Some(previous) = self.previous_cursors.pop() else {
                    return;
                };
                self.model.cursor = previous;
                self.model.page_number = self.previous_cursors.len() + 1;
            }
            Action::Refresh => {}
            _ => return,
        }
        self.generation = self.generation.wrapping_add(1);
        self.model.loading = self.model.view != View::Criteria;
        self.model.detail_loading = self.model.selected_file.is_some();
        self.model.error = None;
        self.model.detail_error = None;
        self.mailbox.submit(Request {
            generation: self.generation,
            view: self.model.view,
            filters: self.model.filters.clone(),
            cursor: self.model.cursor.clone(),
            selected_file: self
                .model
                .selected_file
                .clone()
                .filter(|_| self.model.detail["history_snapshot"] != true),
        });
    }

    fn reset_page(&mut self) {
        self.model.cursor = None;
        self.model.next_cursor = None;
        self.model.page_number = 1;
        self.previous_cursors.clear();
    }

    fn open_folder(&mut self) {
        self.model.view = View::Files;
        self.model.filters.kind.clear();
        self.model.selected_file = None;
        self.model.detail = Value::Null;
        self.model.files = json!({"items": [], "total": 0, "offset": 0, "next_cursor": null});
        self.reset_page();
    }

    fn apply(&mut self, response: Response) {
        if response.generation != self.generation {
            return;
        }
        self.model.loading = false;
        self.model.detail_loading = false;
        self.model.error = response.refresh_error;
        match response.health {
            Ok(health) => {
                self.model.revision = revision_of(&health);
                self.model.health = health;
            }
            Err(error) => self.model.error = Some(error),
        }
        match response.content {
            Ok(content) => {
                if let Some(revision) = revision_of(&content) {
                    self.model.revision = Some(revision);
                }
                match self.model.view {
                    View::Files => {
                        self.model.next_cursor = content["next_cursor"].as_str().map(str::to_owned);
                        self.model.files = content;
                    }
                    View::Overview => self.model.summary = content,
                    View::Scans => self.model.scans = content,
                    View::Criteria => {}
                }
                self.model.last_refresh_ms = Some(response.refreshed_at);
            }
            Err(error) => self.model.error = Some(error),
        }
        if self.model.detail["history_snapshot"] == true {
            return;
        }
        match response.detail {
            Ok(detail) => {
                self.model.detail = detail;
                self.model.detail_error = None;
            }
            Err(error) => {
                self.model.detail = Value::Null;
                self.model.detail_error = Some(error);
            }
        }
    }
}

impl Drop for DashboardController {
    fn drop(&mut self) {
        self.mailbox.closed.store(true, Ordering::Release);

        {
            let mut slots = self
                .mailbox
                .slots
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            slots.request = None;
            slots.response = None;
        }
        self.mailbox.wake.notify_one();
        if let Some(worker) = self.worker.take() {
            let _ = worker.join();
        }
    }
}

fn run_worker(
    mailbox: Arc<Mailbox>,
    mut refresh: impl FnMut() -> Result<(), String>,
    revision: impl Fn() -> u64,
    mut request: impl FnMut(&str) -> Value,
    repaint: impl Fn(),
) {
    let mut current: Option<Request> = None;
    let mut rendered_revision = None;
    let mut next_refresh = Instant::now();
    loop {
        let explicit = {
            let mut slots = mailbox
                .slots
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            loop {
                if mailbox.closed.load(Ordering::Acquire) {
                    return;
                }
                if let Some(next) = slots.request.take() {
                    current = Some(next);
                    break true;
                }
                if current.is_some() && Instant::now() >= next_refresh {
                    break false;
                }
                let timeout = if current.is_some() {
                    next_refresh.saturating_duration_since(Instant::now())
                } else {
                    REFRESH_INTERVAL
                };
                slots = mailbox
                    .wake
                    .wait_timeout(slots, timeout)
                    .unwrap_or_else(|error| error.into_inner())
                    .0;
            }
        };
        let selection = current.as_ref().expect("a request precedes polling");
        let refresh_error = refresh().err();
        let observed_revision = revision();
        if explicit || rendered_revision != Some(observed_revision) || refresh_error.is_some() {
            if let Some(mut response) = load(&mailbox, selection, &mut request) {
                response.refresh_error = refresh_error;
                let succeeded = response.health.is_ok()
                    && response.content.is_ok()
                    && response.refresh_error.is_none();
                if mailbox.publish(response) {
                    rendered_revision = succeeded.then_some(observed_revision);
                    repaint();
                }
            }
        }
        next_refresh = Instant::now() + REFRESH_INTERVAL;
    }
}

fn load(
    mailbox: &Mailbox,
    selection: &Request,
    request: &mut impl FnMut(&str) -> Value,
) -> Option<Response> {
    let mut call = |path: &str| {
        mailbox
            .current(selection.generation)
            .then(|| response_body(request(path)))
    };
    let health = call("/api/v1/health")?;
    let content = match selection.view {
        View::Files => call(&list_path(selection))?,
        View::Overview => call("/api/v1/projects/all/dashboard/summary")?,
        View::Scans => call("/api/v1/projects/all/scans")?,
        View::Criteria => Ok(Value::Null),
    };
    let detail = match &selection.selected_file {
        Some(id) => call(&format!("/api/v1/projects/all/files/{}", encode(id)))?,
        None => Ok(Value::Null),
    };
    Some(Response {
        generation: selection.generation,
        health,
        content,
        detail,
        refresh_error: None,
        refreshed_at: SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis()
            .min(u64::MAX as u128) as u64,
    })
}

fn response_body(response: Value) -> Result<Value, String> {
    if response["status"].as_u64() == Some(200) {
        Ok(response["body"].clone())
    } else {
        Err(response["body"]["error"]["message"]
            .as_str()
            .unwrap_or("데이터를 불러오지 못했습니다.")
            .to_owned())
    }
}

fn revision_of(value: &Value) -> Option<String> {
    value["revision"].as_str().map(str::to_owned)
}

fn list_path(selection: &Request) -> String {
    let filters = &selection.filters;
    let page_size = filters.page_size.clamp(1, 1_000).to_string();
    let pairs = [
        ("folder", filters.folder.as_str()),
        ("q", filters.q.trim()),
        ("kind", filters.kind.as_str()),
        ("severity", filters.severity.as_str()),
        ("scan_status", filters.scan_status.as_str()),
        ("file_status", filters.file_status.as_str()),
        ("category", filters.category.as_str()),
        ("sort", filters.sort.as_str()),
        ("cursor", selection.cursor.as_deref().unwrap_or("")),
        ("limit", page_size.as_str()),
    ];
    let query = pairs
        .into_iter()
        .map(|(key, value)| format!("{key}={}", encode(value)))
        .collect::<Vec<_>>()
        .join("&");
    format!("/api/v1/projects/all/files?{query}")
}

fn encode(value: &str) -> String {
    use std::fmt::Write;
    let mut encoded = String::with_capacity(value.len());
    for byte in value.bytes() {
        if byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b'~') {
            encoded.push(char::from(byte));
        } else {
            write!(&mut encoded, "%{byte:02X}").expect("writing to String cannot fail");
        }
    }
    encoded
}
